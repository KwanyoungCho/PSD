
import pickle
import time
import torch
import torch.distributed as dist
from multiprocessing.synchronize import Event
from multiprocessing.shared_memory import SharedMemory
from transformers import AutoTokenizer, AutoConfig
import os
import flashinfer
from ssd.config import Config
from ssd.engine.sequence import Sequence
from ssd.models.qwen3 import Qwen3ForCausalLM
from ssd.models.qwen2 import Qwen2ForCausalLM
from ssd.models.llama3 import LlamaForCausalLM
from ssd.models.eagle3_draft_llama3 import Eagle3DraftForCausalLM
from ssd.layers.sampler import Sampler
from ssd.utils.context import set_context, reset_context, get_context
from ssd.utils.loader import load_model
from ssd.engine.helpers.runner_helpers import (
    prepare_decode_tensors_from_seqs, 
    prepare_block_tables_from_seqs, 
    prepare_prefill_tensors_from_seqs
)
from ssd.engine.helpers.cudagraph_helpers import (
    run_verify_cudagraph,
    run_decode_cudagraph,
    run_fi_tree_decode_cudagraph,
    run_glue_decode_cudagraph,
    capture_cudagraph,
    capture_verify_cudagraph,
    capture_fi_tree_decode_cudagraph,
    capture_glue_decode_cudagraph,
    capture_duet_verify_cudagraph,
    run_duet_verify_cudagraph,
    get_custom_mask,
)
    

class ModelRunner:

    def __init__(self, config: Config, rank: int, event: Event | list[Event], is_draft: bool = False, num_tp_gpus: int = -1, init_q = None):
        if config.verbose: print(f'ModelRunner init got args: rank={rank}, is_draft={is_draft}, num_tp_gpus={num_tp_gpus}', flush=True)
        self.config = config

        assert is_draft in [True, False], "ERROR in ModelRunner: is_draft must be True or False"
        self.is_draft = is_draft

        # --- Quantization + dtype compatibility gate ---
        #
        # torchao's currently-selected weight-only paths (Int4WeightOnlyConfig /
        # Int8WeightOnlyConfig) are documented as bf16-activation workflows.
        # fp16 checkpoint + these backends is NOT supported:
        #   - Int4WeightOnlyConfig(group_size=128): API-level assert fails
        #     ("Expected Tensor argument zeros to have dtype torch.float16, but got torch.bfloat16")
        #   - Int8WeightOnlyConfig: runs but produces inf in layer output (numerically unreliable)
        # Dense fp16 runtime itself is fine — this is specifically a torchao
        # WO backend × fp16 activation incompatibility.
        #
        # Policy:
        #   (a) bf16-native checkpoint + quant      → works as-is
        #   (b) fp16 checkpoint + quant (no override) → raise ValueError (this block)
        #   (c) fp16 checkpoint + quant + force flag → override runtime to bf16
        #       (effectively a bf16 runtime, not a fp16 runtime — acknowledged workaround)
        # Marlin W4A16 (awq_marlin backend) handles fp16 activation natively,
        # so the bf16-forced-override workaround below does not apply to it.
        _q_backend = getattr(config, 'target_quant_backend', 'int4_wo_tile')
        if getattr(config, 'target_quant_enabled', False) \
                and config.hf_config.torch_dtype == torch.float16 \
                and _q_backend not in ("awq_marlin",):
            if getattr(config, 'target_quant_force_bf16_runtime', False):
                print(
                    f'[quant] target_quant_force_bf16_runtime=True → upcasting '
                    f'hf_config.torch_dtype fp16 -> bf16 (rank={rank}, is_draft={is_draft}). '
                    f'Runtime is now effectively bf16 (NOT a fp16 runtime). '
                    f'Activations, KV cache, graph buffers, draft — all bf16.',
                    flush=True,
                )
                config.hf_config.torch_dtype = torch.bfloat16
            else:
                raise ValueError(
                    f"fp16 checkpoint + target_quant_backend="
                    f"{getattr(config, 'target_quant_backend', '?')!r} is not supported. "
                    f"Selected torchao weight-only backends assume bf16 activation; "
                    f"fp16 activation path fails either at an API dtype assert (int4) "
                    f"or produces inf values in the forward (int8).\n"
                    f"Options:\n"
                    f"  (1) use a bf16 checkpoint (Llama-3 family etc)\n"
                    f"  (2) set target_quant_force_bf16_runtime=True to explicitly "
                    f"opt-in to a bf16 runtime workaround (drops the 'fp16 runtime' "
                    f"guarantee; all hot-path tensors become bf16)\n"
                    f"  (3) switch to a fp16-native WO backend (e.g. GemliteUIntXWeightOnlyConfig, "
                    f"Marlin, etc) — NOT currently integrated."
                )

        if self.is_draft:
            if config.draft_hf_config.torch_dtype != config.hf_config.torch_dtype:
                # Use config.verbose directly — self.verbose is assigned later in __init__.
                if config.verbose:
                    print(f"Warning: Draft dtype {config.draft_hf_config.torch_dtype} differs from target {config.hf_config.torch_dtype}. Casting draft to {config.hf_config.torch_dtype}.")
                config.draft_hf_config.torch_dtype = config.hf_config.torch_dtype
            assert (config.draft_hf_config.vocab_size == config.hf_config.vocab_size) or config.use_eagle, "ERROR in ModelRunner: draft_hf_config.vocab_size != hf_config.vocab_size"

        self.hf_config = config.hf_config if not is_draft else config.draft_hf_config
        # Qwen2 configs (e.g. Qwama-0.5B) do not expose head_dim directly.
        # Multiple downstream paths (allocate_kv_cache, FlashInfer plan,
        # cudagraph helpers) read hf_config.head_dim as a plain attribute.
        # Inject the derived value once so those sites do not need a
        # getattr fallback each.
        if not hasattr(self.hf_config, 'head_dim') or self.hf_config.head_dim is None:
            self.hf_config.head_dim = (
                self.hf_config.hidden_size // self.hf_config.num_attention_heads
            )
        self.block_size = config.kvcache_block_size
        self.enforce_eager = config.enforce_eager
        _tok_path = config.tokenizer_path if config.tokenizer_path else config.model
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(_tok_path, use_fast=True)
        except Exception:
            self.tokenizer = AutoTokenizer.from_pretrained(_tok_path, use_fast=False)
        self.max_num_blocks = (config.max_model_len + self.block_size - 1) // self.block_size

        assert self.hf_config is not None, "ERROR in ModelRunner: hf_config is None" # this implies boundedness to the end 
        
        # TODO: Get rid of this.
        if self.is_draft:
            should_use_dist = self.config.draft_async
        else:
            should_use_dist = self.config.num_gpus > 1

        # determines whether we create a process group and our process is aware of others, etc
        self.world_size = config.num_gpus if should_use_dist else 1
        self.rank = rank
        self.use_eagle = config.use_eagle

        if config.draft_async:
            self.draft_rank = config.num_gpus - 1
            if self.is_draft:
                # [N, 3] int64, {(seq_id, len(new_suffix), rec_token): (speculated_tokens, logits_q)}
                self.prev_fork_keys: torch.Tensor | None = None
                self.prev_fork_block_tables: torch.Tensor | None = None  # [N, M] int32 with -1 padding

        self.num_tp_gpus = num_tp_gpus # will be in [1 if no dist, num_gpus if not async, num_gpus-1 if async]
        
        if self.world_size == 1: # sync speculation or genuine single gpu 
            assert (config.speculate and not config.draft_async) or self.num_tp_gpus == 1, "ERROR in ModelRunner: draft and async must be False or num_tp_gpus=1"

        self.verbose = config.verbose
        self.draft_async = config.draft_async
        self.event = event
        self._exiting = False
        self._duet_proxy_fn = None  # DUET: Verifier sets before verify, clears after
        # Batch 3b (docs/duet/08 §1): dedicated CUDA stream for the rank-0-only
        # proxy callback so Policy B compute + isend can overlap with
        # graph_post.replay() on the default stream. Lazy-init on first use
        # gated by SSD_PROXY_STREAM=1 (default OFF). Ranks 1+ never allocate.
        self._duet_proxy_stream = None
        
        torch.cuda.set_device(self.rank)
        self.device = torch.device(f'cuda:{self.rank}') 
        
        # cudagraph logic for FlashInfer kernels, need diff wrapper for each batch size we make a graph for 
        if is_draft and config.draft_async:
            self._init_flashinfer_wrappers()
        # P2-tree (T3.1, docs/duet/internal/20): target rank들도 tree-verify용
        # FlashInfer wrapper/workspace 필요 (기존엔 draft 전용 — 리뷰4
        # 확인). tree policy 게이트 — off면 무할당 (OFF 경로 불변).
        self.tree_verify_wrappers = None
        from ssd.engine.helpers.batch_tree_common import enabled as batch_tree_enabled
        self.batched_tree_enabled = batch_tree_enabled(config)
        if (not is_draft) and getattr(config, "duet_enabled", False) \
                and getattr(config, "duet_tree_enabled", False) and not self.batched_tree_enabled:
            self._init_tree_verify_wrappers()
        
        if self.verbose: print(f'INSIDE MODEL RUNNER INIT, DRAFT={is_draft}', flush=True)
        self.tp_pg = None 

        if should_use_dist:
            default_port = int(os.environ.get("SSD_DIST_PORT", "1223"))
            dist.init_process_group(
                "nccl", f"tcp://localhost:{default_port}",
                world_size=self.world_size,
                rank=self.rank,
                device_id=self.device,
            )

            self.tp_pg = dist.new_group(ranks=list(range(self.num_tp_gpus))) # everyone should see the new_group init even if not in group 

        default_dtype = torch.get_default_dtype()
        # hf_config.torch_dtype was already updated near __init__ if quantization
        # is enabled and original model is fp16, so this sets the correct dtype
        # for both the model weights and any helpers reading hf_config.torch_dtype.
        torch.set_default_dtype(self.hf_config.torch_dtype)
        torch.set_default_device("cuda")
        
        if self.is_draft:
            assert num_tp_gpus == 1, "ERROR in ModelRunner: draft should have tp_size=1"
            self.tp_pg = None # every rank is given an object from self.tp_pg, even tho draft doesnt participate it gets GROUP_NON_MEMBER object != None back, so we can't assert None here, we 
        
        print(f'[model_runner] about to setup and warmup model and cudagraphs, is use_eagle={self.use_eagle}', flush=True)
        model_type = self.setup_and_warmup_model_and_cudagraphs(config, self.hf_config, init_q, is_draft)

        if self.verbose: print(f'-----CAPTURED {model_type}CUDAGRAPH----', flush=True)
        torch.set_default_device("cpu")
        torch.set_default_dtype(default_dtype)

        if self.config.draft_async:
            # fan_out_list is always set by Config.__post_init__ — the former
            # re-derivation here was a dead duplicate (docs/duet/16 Tier-3).
            self.config.fan_out_t = torch.tensor(self.config.fan_out_list, device=self.device)
            self.config.fan_out_t_miss = torch.tensor(self.config.fan_out_list_miss, device=self.device)
            assert len(self.config.fan_out_list) == self.config.speculate_k + \
                1, "ERROR in Config: fan_out_list must be length speculate_k + 1"
            assert any(f > 0 for f in self.config.fan_out_list), "ERROR in Config: fan_out_list must be > 0"
            self.config.MQ_LEN = sum(self.config.fan_out_list)
            print(f'F={self.config.async_fan_out}, fan_out_list={self.config.fan_out_list}, fan_out_list_miss={self.config.fan_out_list_miss}, MQ_LEN={self.config.MQ_LEN}', flush=True)

        if should_use_dist: # (draft model when async=False or just single gpu logic) doesn't even enter this loop 
            # One namespace per engine, inherited by spawned TP workers.
            # Never unlink another experiment's shared-memory segment.
            shm_name = os.environ.get("SSD_SHM_NAME", "ssd")
            if self.is_draft and self.draft_async: 
                pass # handled on draft runner after this init, includes doing draft_loop
            elif self.rank == 0: # target in a distributed setup 
                # Try to clean up any existing shared memory first
                try:
                    existing_shm = SharedMemory(name=shm_name)
                    existing_shm.close() # here we bind it 
                    existing_shm.unlink()
                except FileNotFoundError:
                    # can proceed, nothing to clean up 
                    pass
                
                self.shm = SharedMemory(name=shm_name, create=True, size=2**28)
                dist.barrier(group=self.tp_pg, device_ids=[self.rank]) # leader on tp_group 
            else: 
                dist.barrier(group=self.tp_pg, device_ids=[self.rank]) # follower on tp_group, don't want them hooking onto shm before its been created 
                self.shm = SharedMemory(name=shm_name)
                self.loop()
                
        if self.verbose: print(f'-----{model_type}MODEL RUNNER INITIALIZED----', flush=True)

    def _init_tree_verify_wrappers(self):
        """T3.1 — target rank-로컬 tree-verify wrapper (N_v bucket별).

        리뷰4 반영: workspace는 rank당 1개 공유, 128MB (FlashInfer 권장
        — draft의 512MB는 그쪽 선택값), KV cache 할당 전에 잡는다
        (이 함수는 __init__ 초기에 호출됨). bucket = N_v+1 행 고정
        (B=1 — v6: B>1은 tree 게이트 OFF).
        """
        import flashinfer
        nv = int(self.config.duet_tree_wire_nodes)
        max_blocks = (self.config.max_model_len + self.block_size - 1) \
            // self.block_size
        self._tree_workspace = torch.zeros(
            128 * 1024 * 1024, dtype=torch.uint8, device=self.device)
        # One persistent copy of the common P1/P2 tree wire for target TP
        # followers.  Rank 0 consumes the response tensor directly; followers
        # receive the same validated metadata through SHM and perform one H2D
        # copy before the GPU topology kernels.
        self._tree_wire_device = torch.empty(
            3 + 4 * nv, dtype=torch.int64, device=self.device)
        self.tree_verify_wrappers = {}
        # Production backbone generation fills the configured per-root cap.
        # Capture only the active phase caps; intermediate valid counts pad
        # to the next cap (and the rare support-exhaustion shape can use the
        # same bucket).  Capturing every even node count multiplied by every
        # page count wastes several GiB once each graph gets the isolated
        # FlashInfer state required for correctness.
        verify_buckets = set()
        if self.config.duet_p1_tree_policy == "on":
            verify_buckets.add(int(self.config.duet_p1_tree_verify_nodes))
        if self.config.duet_p2_tree_policy == "on":
            verify_buckets.add(int(self.config.duet_p2_tree_verify_nodes))
        if not verify_buckets:
            verify_buckets.add(nv)

        def _new_wrapper(nv_b, workspace, page_capacity):
            r = nv_b + 1
            w = flashinfer.BatchPrefillWithPagedKVCacheWrapper(
                workspace, "NHD", backend="fa2", use_cuda_graph=True,
                qo_indptr_buf=torch.empty(2, dtype=torch.int32,
                                          device=self.device),
                paged_kv_indptr_buf=torch.empty(2, dtype=torch.int32,
                                                device=self.device),
                paged_kv_indices_buf=torch.empty(
                    page_capacity, dtype=torch.int32, device=self.device),
                paged_kv_last_page_len_buf=torch.empty(
                    1, dtype=torch.int32, device=self.device),
                custom_mask_buf=torch.empty(
                    (r * page_capacity * self.block_size + 7) // 8,
                    dtype=torch.uint8, device=self.device),
                mask_indptr_buf=torch.empty(2, dtype=torch.int32,
                                            device=self.device),
            )
            w._kv_lens_buffer = torch.empty(
                1, dtype=torch.int32, device=self.device)
            return w

        for nv_b in sorted(verify_buckets):
            self.tree_verify_wrappers[nv_b] = _new_wrapper(
                nv_b, self._tree_workspace, max_blocks)

        # A captured FlashInfer graph also closes over plan-specific
        # auxiliary workspace contents.  Sharing a wrapper/workspace across
        # page shapes made later captures silently corrupt earlier graphs.
        # Keep one modest workspace per (node,page) graph, matching the
        # isolation rule already used by P2TreeExecutor.
        # FlashInfer's temporary storage grows with the verify query width.
        # 64 MiB is sufficient through six verify nodes, but FlashInfer
        # switches kernels at eight nodes for this Llama-2-70B shape and then
        # requests about 82 MiB (P1=18 has the same observed requirement).
        # Keep the smaller allocation only for narrow trees.  The environment
        # override is intentionally retained for other models whose
        # requirement differs.
        default_graph_ws_mb = 96 if max(verify_buckets) > 6 else 64
        graph_ws_mb = int(os.environ.get(
            "SSD_TREE_VERIFY_WORKSPACE_MB", str(default_graph_ws_mb)))
        if graph_ws_mb <= 0:
            raise ValueError("SSD_TREE_VERIFY_WORKSPACE_MB must be positive")
        self._tree_verify_graph_workspaces = {}
        self.tree_verify_graph_wrappers = {}
        for nv_b in sorted(verify_buckets):
            for n_pages in range(1, max_blocks + 1):
                key = (int(nv_b), int(n_pages))
                ws = torch.empty(
                    graph_ws_mb * 2**20, dtype=torch.uint8,
                    device=self.device)
                self._tree_verify_graph_workspaces[key] = ws
                self.tree_verify_graph_wrappers[key] = _new_wrapper(
                    int(nv_b), ws, int(n_pages))

    def _init_flashinfer_wrappers(self):
        """Initialize FlashInfer wrappers for draft async mode."""
        self.workspace_buffer = torch.zeros(
            512 * 1024 * 1024, dtype=torch.uint8, device=f"cuda:{self.rank}") 
        
        if self.config.enforce_eager: 
            self.only_prefill_wrapper = flashinfer.BatchPrefillWithPagedKVCacheWrapper(self.workspace_buffer, "NHD")
        else: 
            max_bs = min(self.config.max_num_seqs, 512)
            max_num_blocks = (self.config.max_model_len + self.block_size - 1) // self.block_size
            
            # FlashInfer kernel tensors
            # pages_for_max_len = (self.config.max_model_len + self.block_size - 1) // self.block_size
            last_page_len_max_len = self.config.max_model_len % self.block_size
            last_page_len_max_len = self.block_size if last_page_len_max_len == 0 else last_page_len_max_len
            MQ_LEN = self.config.async_fan_out * (self.config.speculate_k + 1)
            
            cu_seqlens_q = torch.empty(max_bs + 1, dtype=torch.int32, device=self.device)
            kv_indptr = torch.empty(max_bs + 1, dtype=torch.int32, device=self.device)
            kv_indices = torch.empty(max_bs * max_num_blocks, dtype=torch.int32, device=self.device)
            kv_last_page_len = torch.empty(max_bs, dtype=torch.int32, device=self.device)
            custom_mask_buf = torch.empty(max_bs * MQ_LEN * self.config.max_model_len, dtype=torch.uint8, device=self.device)
            mask_indptr_buf = torch.empty(max_bs + 1, dtype=torch.int32, device=self.device)
            
            # Create graph_bs_list to match what will be used in cudagraph_helpers.py
            graph_bs_list = [1]
            for bs in [2, 4, 8] + list(range(16, max_bs + 1, 16)):
                if bs <= max_bs:
                    graph_bs_list.append(bs)
            if max_bs not in graph_bs_list:
                graph_bs_list.append(max_bs)
            graph_bs_list.sort()
            
            # Create a dict of wrappers, one for each bs we will touch in cudagraph_helpers.py
            self.prefill_wrappers = {}
            print(f'[model_runner about to wrapper.init()] graph_bs_list={graph_bs_list}', flush=True)
            for bs in graph_bs_list:
                self.prefill_wrappers[bs] = flashinfer.BatchPrefillWithPagedKVCacheWrapper(
                    self.workspace_buffer, "NHD", 
                    use_cuda_graph=True, 
                    qo_indptr_buf=cu_seqlens_q[:bs + 1],
                    paged_kv_indptr_buf=kv_indptr[:bs + 1],
                    paged_kv_indices_buf=kv_indices[:bs * max_num_blocks],
                    paged_kv_last_page_len_buf=kv_last_page_len[:bs],
                    custom_mask_buf=custom_mask_buf[:bs * MQ_LEN * self.config.max_model_len],
                    mask_indptr_buf=mask_indptr_buf[:bs + 1],
                )
            print(f'wrapper backend is {self.prefill_wrappers[bs]._backend}', flush=True)

            # DUET: create layout-specific wrappers for split-K1/K2 tree
            # decode (split_k1_{long,short} + split_k2). The hybrid / legacy
            # draft-proxy wrapper families were removed (2026-07).
            self.prefill_wrappers_by_layout = {"full": self.prefill_wrappers}
            if self.config.duet_enabled:
                # K2 <= K1 contract (asserted at draft init).
                # Phase 1 supports non-uniform fan_out_list per position
                # (config.duet_split_phase1_fan_out_list). Phase 2 is
                # uniform proxy_fo (split-K1/K2 design).
                K1_cfg_split = self.config.duet_phase1_k
                K2_cfg_split = self.config.duet_phase2_k
                _p1_list = self.config.duet_split_phase1_fan_out_list
                _dfo = self.config.duet_draft_fan_out
                _pfo = self.config.duet_proxy_fan_out
                _p1_mq_long = sum(_p1_list) if _p1_list else _dfo * (K1_cfg_split + 1)
                _layout_specs = [("split_k1_long", _p1_mq_long)]
                if K2_cfg_split < K1_cfg_split:
                    _p1_mq_short = (
                        sum(_p1_list[:K2_cfg_split + 1]) if _p1_list
                        else _dfo * (K2_cfg_split + 1)
                    )
                    _layout_specs.append(("split_k1_short", _p1_mq_short))
                # Phase 2 worst-case sizing for unified Policy B (옵션 A-1).
                # docs/duet/05-policy-b-fix.md Section 3.7.
                # MQ_LEN = total_budget = pfo*(K_max+1). Phase 2 tree size
                # is uniform across hit types (option A: work uniform, no
                # short-hit savings). wire_N (=total_budget+buffer) is
                # NCCL-pack only and unrelated to layout MQ_LEN.
                K_rank_max = max(K1_cfg_split, K2_cfg_split)   # = K1
                _p2_mq = self.config.duet_proxy_total_budget  # Tier-3 single source
                _layout_specs.append(("split_k2", _p2_mq))
                if self.config.duet_tree_enabled:
                    # One generic glue materialization graph serves both P1
                    # and P2 tree hits.  Its rows are recovery + the common
                    # maximum number of tree nodes; live rows are masked and
                    # the tail uses slot=-1.
                    _layout_specs.append((
                        "tree_glue", self.config.duet_tree_wire_nodes + 1))
                for layout_name, layout_mq_len in _layout_specs:
                    l_cu = torch.empty(max_bs + 1, dtype=torch.int32, device=self.device)
                    l_kv_indptr = torch.empty(max_bs + 1, dtype=torch.int32, device=self.device)
                    l_kv_indices = torch.empty(max_bs * max_num_blocks, dtype=torch.int32, device=self.device)
                    l_kv_lpl = torch.empty(max_bs, dtype=torch.int32, device=self.device)
                    l_mask = torch.empty(max_bs * layout_mq_len * self.config.max_model_len,
                                          dtype=torch.uint8, device=self.device)
                    l_mask_indptr = torch.empty(max_bs + 1, dtype=torch.int32, device=self.device)

                    layout_wrappers = {}
                    for bs_i in graph_bs_list:
                        layout_wrappers[bs_i] = flashinfer.BatchPrefillWithPagedKVCacheWrapper(
                            self.workspace_buffer, "NHD",
                            use_cuda_graph=True,
                            qo_indptr_buf=l_cu[:bs_i + 1],
                            paged_kv_indptr_buf=l_kv_indptr[:bs_i + 1],
                            paged_kv_indices_buf=l_kv_indices[:bs_i * max_num_blocks],
                            paged_kv_last_page_len_buf=l_kv_lpl[:bs_i],
                            custom_mask_buf=l_mask[:bs_i * layout_mq_len * self.config.max_model_len],
                            mask_indptr_buf=l_mask_indptr[:bs_i + 1],
                        )
                    self.prefill_wrappers_by_layout[layout_name] = layout_wrappers
                print(f'[DUET] Created FlashInfer wrappers for split-K1/K2 layouts', flush=True)


    def setup_and_warmup_model_and_cudagraphs(self, config: Config, hf_config: AutoConfig, init_q=None, is_draft=False):
        # cudagraphs 
        self.graph_vars = {}
        self.graph_pools = {}
        self.graphs = {}
        self.graph_bs_list = {}

        assert hasattr(hf_config, 'model_type'), "ERROR in ModelRunner: hf_config.model_type is not set"
        if config.use_eagle and is_draft:
            print(f'[EAGLE3] Loading Eagle3DraftForCausalLM as model_class', flush=True)
            model_class = Eagle3DraftForCausalLM
        elif hf_config.model_type == 'llama':
            model_class = LlamaForCausalLM
        elif hf_config.model_type == 'qwen3':
            model_class = Qwen3ForCausalLM
        elif hf_config.model_type == 'qwen2':
            model_class = Qwen2ForCausalLM
        else:
            raise ValueError(f"Unsupported model type: {hf_config.model_type}")

        # only give Qwen3 a tp_group if we're a TARGET runner
        kwargs = dict(
            config=self.hf_config,
            draft=self.is_draft,
            speculate=self.config.speculate,
            spec_k=self.config.speculate_k,
            async_fan_out=self.config.async_fan_out,
            draft_async=self.config.draft_async,
            tp_group=self.tp_pg,
            tp_size=self.num_tp_gpus,
        )
        
        if config.use_eagle:
            kwargs['use_eagle'] = True
            kwargs['eagle_layers'] = self.config.eagle_layers
            
        if model_class == Eagle3DraftForCausalLM:
            kwargs['d_model_target'] = config.d_model_target
            kwargs['debug_mode'] = config.debug_mode

        # AWQ: derive role-specific structured QuantConfigs at the runner
        # boundary (plan §13.3 migration path). Target and draft configs are
        # independent; either can be enabled alone. Downstream AWQ code
        # reads only `self.quant_config` (the active one for this runner).
        from ssd.quant.config import quant_config_from_legacy_flags
        role = "draft" if is_draft else "target"
        self.quant_config = quant_config_from_legacy_flags(config, role)
        _awq_active = self.quant_config is not None and self.quant_config.enabled

        # Eagle draft AWQ is not supported in this first pass — fail loudly
        # rather than silently quantize the wrong module set.
        if _awq_active and is_draft and getattr(config, "use_eagle", False):
            raise ValueError(
                "draft_quant_enabled=True with use_eagle=True is NOT supported "
                "in this version (non-EAGLE drafts only). Disable draft AWQ "
                "or use a non-EAGLE draft model."
            )

        if _awq_active:
            from ssd.quant.init_context import quant_init_context
            with quant_init_context():
                self.model = model_class(**kwargs)
        else:
            self.model = model_class(**kwargs)
        # Keep both flags for readability downstream. _awq_target retained for
        # backward-compat reads outside the runner (nothing else sets this).
        self._awq_active = _awq_active
        self._awq_target = _awq_active and not is_draft
        self._awq_draft = _awq_active and is_draft

        model_type = "DRAFT " if self.is_draft else "TARGET "
        if self.verbose:
            print(f'-----LOADING {model_type}MODEL----', flush=True)
        
        # Pass tokenizer_path as target_path if it's available (mostly for Eagle draft)
        target_path = getattr(config, 'tokenizer_path', None)
        target_hidden_size = getattr(config, 'd_model_target', None)
        load_model(self.model, config.model, target_path=target_path, target_hidden_size=target_hidden_size)
        # Inference only.  On sm_120 this also prevents torch.compile from
        # attempting an AOTAutograd backward trace through in-place RMSNorm.
        self.model.requires_grad_(False)

        # --- AWQ W4A16 path (plan v2 — see INT8-WEIGHT-ONLY-PLAN-v2.md) ---
        # Runs identically for target and draft; the QuantConfig instance
        # carries the role so the loader validates the artifact is the
        # correct kind.
        if self._awq_active:
            qc = self.quant_config
            _tp_size_awq = self.num_tp_gpus if hasattr(self, 'num_tp_gpus') else 1
            _tp_rank_awq = dist.get_rank(group=self.tp_pg) if self.tp_pg is not None else 0
            # Draft is always tp_size=1 in this version; cross-check.
            if qc.role == "draft":
                assert _tp_size_awq == 1, \
                    f"draft AWQ requires tp_size=1 in v1, got {_tp_size_awq}"
            # Opt-in group-size sanity check (only if user set it non-default).
            _user_group_size = None
            if qc.role == "target":
                _gs = getattr(config, 'target_quant_group_size', None)
                if _gs is not None and _gs != 128:
                    _user_group_size = qc.group_size
            else:
                _gs = getattr(config, 'draft_quant_group_size', None)
                if _gs is not None and _gs != 128:
                    _user_group_size = qc.group_size

            if qc.quant_source == "ssd_artifact":
                if not qc.artifact_path:
                    raise ValueError(
                        f"QuantConfig[{qc.role}].quant_source=ssd_artifact requires "
                        f"artifact_path (CLI --quant_awq{'_draft' if qc.role=='draft' else ''}_artifact)."
                    )
                from ssd.quant.loader import apply_ssd_awq_artifact
                apply_ssd_awq_artifact(
                    self.model,
                    prefix=qc.artifact_path,
                    tp_rank=_tp_rank_awq,
                    tp_size=_tp_size_awq,
                    expected_runtime_dtype=qc.expected_runtime_dtype,
                    expected_model_id=os.path.abspath(config.model),
                    expected_group_size=_user_group_size,
                    expected_role=qc.role,
                )
            elif qc.quant_source == "external_awq":
                if not qc.external_quant_path:
                    raise ValueError(
                        f"QuantConfig[{qc.role}].quant_source=external_awq requires "
                        f"external_quant_path."
                    )
                from ssd.quant.adapter import load_external_autoawq_into_model
                load_external_autoawq_into_model(
                    self.model,
                    hf_path=qc.external_quant_path,
                    tp_rank=_tp_rank_awq,
                    tp_size=_tp_size_awq,
                    expected_role=qc.role,
                )
            else:
                raise ValueError(f"Unknown QuantConfig.quant_source={qc.quant_source!r}")

        # === LEGACY torchao weight-only path (DEPRECATED, internal fallback) ===
        # The supported public path is AWQ Marlin above. This branch is kept
        # only as an internal fallback for bf16-native targets that hit a
        # corner case in AWQ. CLI flags that drive this path were removed
        # from bench.py — to use it now you must set
        # `target_quant_backend in ("int4_wo_tile", "int8_wo")` directly on
        # the `Config` dataclass. Expect removal in a follow-up cleanup.
        if getattr(config, 'target_quant_enabled', False) and not is_draft \
                and not self._awq_target:
            print(
                "[quant][LEGACY] torchao weight-only path triggered "
                "(target_quant_backend=%r). This path is deprecated; "
                "the supported route is `--quant_awq` + AWQ artifact." %
                getattr(config, 'target_quant_backend', '?'),
                flush=True,
            )
            from ssd.utils.quantize import (
                apply_quantization_to_target,
                save_quantized_target_artifact,
                load_quantized_target_artifact,
            )
            import os as _os_qskip
            # Accept both SSD_QUANT_SKIP (preferred, backend-agnostic) and SSD_INT8_SKIP (legacy alias).
            _skip_csv = _os_qskip.environ.get("SSD_QUANT_SKIP", _os_qskip.environ.get("SSD_INT8_SKIP", ""))
            _skip_subs = tuple(s.strip() for s in _skip_csv.split(",") if s.strip())
            _backend = getattr(config, 'target_quant_backend', 'int4_wo_tile')
            _mode = getattr(config, 'target_quant_mode', 'load_time')
            _prefix = getattr(config, 'target_quant_artifact_prefix', None)
            # Fallback matches config.py default (False). If runtime passes a legacy Config
            # object without this attr we should still keep lm_head dense by default.
            _lm_head = getattr(config, 'target_quant_lm_head', False)
            _tp_size = self.num_tp_gpus if hasattr(self, 'num_tp_gpus') else 1
            _tp_rank = dist.get_rank(group=self.tp_pg) if self.tp_pg is not None else 0

            _loaded_from_artifact = False
            # TODO (perf, Phase 5 follow-up): currently load_model() runs before
            # the artifact check, so the full float target weights (e.g. 70B ~70GB
            # bf16 per rank) are paged into GPU only to be discarded on artifact
            # load. For the persistent-artifact path we could skip load_model
            # entirely and only load embed/norm + replace the TP-linear weights
            # from the artifact. Non-trivial because loader.py orchestrates full
            # safetensors streaming; leaving as TODO until 70B experiments need it.
            if _prefix is not None:
                import os as _os_ar
                _art_path = f"{_prefix}.rank{_tp_rank}.pt"
                if _os_ar.path.exists(_art_path):
                    print(f'[quant] loading artifact rank={_tp_rank}: {_art_path}', flush=True)
                    load_quantized_target_artifact(
                        self.model, _prefix,
                        tp_rank=_tp_rank, tp_size=_tp_size,
                        expected_backend=_backend,
                        expected_quantize_lm_head=_lm_head,
                        expected_model_id=getattr(config, 'model', None),
                        expected_runtime_dtype=self.hf_config.torch_dtype,
                    )
                    _loaded_from_artifact = True
                elif _mode == 'persistent':
                    raise FileNotFoundError(f"mode=persistent but artifact missing: {_art_path}")

            if not _loaded_from_artifact:
                print(f'[quant] quantizing target (rank={_tp_rank}, backend={_backend}, lm_head={_lm_head}, skip={_skip_subs})', flush=True)
                apply_quantization_to_target(
                    self.model,
                    quantize_lm_head=_lm_head,
                    tie_word_embeddings=getattr(hf_config, 'tie_word_embeddings', False),
                    verbose=True,
                    skip_module_name_substrings=_skip_subs,
                    backend=_backend,
                )
                if _prefix is not None and _mode == 'load_time':
                    # Original checkpoint dtype (pre-upcast): read from hf_config's
                    # original file, not the possibly-mutated runtime value.
                    # hf_config.json path → torch_dtype field → fp16 or bf16 string.
                    from transformers import AutoConfig as _AC
                    try:
                        _orig_ckpt_dtype = _AC.from_pretrained(config.model).torch_dtype
                    except Exception:
                        _orig_ckpt_dtype = self.hf_config.torch_dtype
                    save_quantized_target_artifact(
                        self.model, _prefix,
                        backend=_backend, tp_rank=_tp_rank, tp_size=_tp_size,
                        quantize_lm_head=_lm_head,
                        effective_runtime_dtype=self.hf_config.torch_dtype,
                        original_checkpoint_dtype=_orig_ckpt_dtype,
                        model_id=getattr(config, 'model', None),
                    )

            # Optional layer-1 forward hooks for root-cause diagnosis
            from ssd.utils.int8_debug import debug_enabled, install_layer1_hooks
            if debug_enabled():
                install_layer1_hooks(self.model, rank=self.rank, target_layer_idx=1, call_limit=4)

        if config.draft_async:  # move this here so we don't get a timeout waiting for draft rank while load_model happens?
            self.async_pg = dist.new_group(ranks=[0, self.draft_rank])
        if self.verbose:
            print(f'-----{model_type}MODEL LOADED----', flush=True)
        if config.sampler_x is not None:
            assert config.draft_async, "ERROR in ModelRunner: sampler_x requires draft_async"
            assert sum(config.fan_out_list) == sum(config.fan_out_list_miss) == config.async_fan_out * (config.speculate_k + 1), "ERROR in ModelRunner: fancy sampling only supported for constant fan out for now."

        self.sampler = Sampler(sampler_x=config.sampler_x, async_fan_out=config.async_fan_out,
                               greedy_only=config.greedy_only, stochastic_only=config.stochastic_only)

        # DUET exit-replica (SSD_DUET_EXIT_REPLICA=1, docs/duet/09 WS3c):
        # rank 0 keeps a full-vocab lm_head replica so the mid-verify exit
        # proxy needs NO TP collective. One-time weight gather over the TP
        # group (all target ranks participate); built BEFORE
        # allocate_kv_cache so KV auto-sizing accounts for the extra
        # V×D fp16 (~512MB at 70B).
        if (not is_draft and config.duet_enabled
                and getattr(config, "duet_exit_replica", False)):
            _lm = self.model.lm_head
            _w = _lm.weight.data
            if _lm.tp_size > 1:
                _parts = ([torch.empty_like(_w) for _ in range(_lm.tp_size)]
                          if _lm.tp_rank == 0 else None)
                dist.gather(_w, _parts, 0, group=_lm.tp_group)
                if _lm.tp_rank == 0:
                    self._duet_lm_head_replica = torch.cat(_parts, dim=0)
            else:
                self._duet_lm_head_replica = _w
            if _lm.tp_rank == 0:
                print(f'[duet] exit-replica lm_head on rank0: '
                      f'{list(self._duet_lm_head_replica.shape)}', flush=True)

        if self.verbose:
            print(f'-----WARMING UP {model_type}MODEL----', flush=True)
        self.warmup_model()
        self._warmup_tree_proxy()
        if self.verbose:
            print(f'-----ALLOCATING {model_type}KV CACHE----', flush=True)
        self.allocate_kv_cache()
        self._capture_tree_proxy_graphs()
        if init_q is not None:
            # super().__init__() runs warmup and calculates num_kvcache_blocks, pass that up
            init_q.put(self.config.num_kvcache_blocks)
            # DraftRunner still has layout-specific and P2 CUDA graphs to
            # capture after this base-class method returns.  Keep the queue
            # open so it can send a second, real readiness message.  Closing
            # here made the parent advertise a ready engine while the first
            # generation was still paying those captures.

        if not self.enforce_eager:
            # if not self.is_draft or (self.is_draft and self.config.draft_async and self.config.speculate): 
            decode_graph_vars, decode_graph_pool, decode_graphs, decode_graph_bs_list = capture_cudagraph(self)  # decode cudagraph, draft needs in spec and target in normal
            self.graph_vars["decode"] = decode_graph_vars
            self.graph_pools["decode"] = decode_graph_pool
            self.graphs["decode"] = decode_graphs
            self.graph_bs_list["decode"] = decode_graph_bs_list
            if self.config.speculate and not self.batched_tree_enabled and not (self.is_draft and self.config.use_eagle):  # verify CG: target always, non-EAGLE draft for fan-out; EAGLE draft uses glue_decode CG instead
                if self.config.duet_enabled and not self.is_draft:
                    # DUET target: split verify CudaGraph (skip full verify → VRAM saving).
                    # Split-only K1/K2 mode: target verify per-bucket
                    # captures (duet_verify_k1, duet_verify_k2). Single
                    # bucket dispatch by valid_k. K1==K2 is fine (still
                    # capture both for clean dispatch logic).
                    K1 = self.config.duet_phase1_k
                    K2 = self.config.duet_phase2_k
                    duet_gv_k1, duet_pool_k1, duet_pre_k1, duet_post_k1, duet_bs_k1 = \
                        capture_duet_verify_cudagraph(self, lookahead=K1, graph_pool=None)
                    self.graph_vars["duet_verify_k1"] = duet_gv_k1
                    self.graph_pools["duet_verify_k1"] = duet_pool_k1
                    self.graphs["duet_verify_k1_pre"] = duet_pre_k1
                    self.graphs["duet_verify_k1_post"] = duet_post_k1
                    self.graph_bs_list["duet_verify_k1"] = duet_bs_k1
                    # Skip duet_verify_k2 capture when K1==K2 (same as k1).
                    if K2 < K1:
                        duet_gv_k2, duet_pool_k2, duet_pre_k2, duet_post_k2, duet_bs_k2 = \
                            capture_duet_verify_cudagraph(self, lookahead=K2, graph_pool=None)
                        self.graph_vars["duet_verify_k2"] = duet_gv_k2
                        self.graph_pools["duet_verify_k2"] = duet_pool_k2
                        self.graphs["duet_verify_k2_pre"] = duet_pre_k2
                        self.graphs["duet_verify_k2_post"] = duet_post_k2
                        self.graph_bs_list["duet_verify_k2"] = duet_bs_k2
                    print(f'[DUET split-K1K2] Captured duet_verify_k1 CG (K1={K1})'
                          + (f' + duet_verify_k2 CG (K2={K2})' if K2 < K1
                             else f' (K2==K1, k2 SKIPPED)'),
                          flush=True)
                    # T3.2: P2-tree verify bucket capture (policy != off)
                    if getattr(self.config, "duet_tree_enabled", False) \
                            and getattr(
                                self, "tree_verify_wrappers", None):
                        from ssd.engine.helpers.cudagraph_helpers import (
                            capture_tree_verify_cudagraph)
                        self._tree_verify_cg, _tree_pool = \
                            capture_tree_verify_cudagraph(
                                self, graph_pool=duet_pool_k1)
                        self.graph_pools["tree_verify"] = _tree_pool
                        self._warmup_tree_topology_gpu()
                        print(f'[DUET tree] Captured tree_verify CG '
                              f'(buckets={sorted(self._tree_verify_cg)})',
                              flush=True)
                else:
                    _split_k1k2_draft = (
                        self.is_draft
                        and self.config.duet_phase1_k is not None
                        and os.environ.get("SSD_FORCE_SPLIT_K1K2", "0") == "1"
                    )
                    # Full `verify` CG (K_long+1) is NOT used by the
                    # split-only DUET draft path. Skip in split mode.
                    if not _split_k1k2_draft:
                        # Non-DUET: full verify CudaGraph (K+1 wide)
                        verify_graph_vars, verify_graph_pool, verify_graphs, verify_graph_bs_list = capture_verify_cudagraph(self)
                        self.graph_vars["verify"] = verify_graph_vars
                        self.graph_pools["verify"] = verify_graph_pool
                        self.graphs["verify"] = verify_graphs
                        self.graph_bs_list["verify"] = verify_graph_bs_list

                    if self.is_draft and self.config.duet_phase1_k is not None:
                        # Split-only K1/K2 mode: draft glue per-bucket captures
                        # (verify_k1, verify_k2). Dispatch by valid_k.
                        if os.environ.get("SSD_FORCE_SPLIT_K1K2", "0") == "1":
                            K1 = self.config.duet_phase1_k
                            K2 = self.config.duet_phase2_k
                            v_k1_gv, v_k1_pool, v_k1_graphs, v_k1_bs = capture_verify_cudagraph(
                                self, k_plus_1=K1 + 1,
                            )
                            self.graph_vars["verify_k1"] = v_k1_gv
                            self.graph_pools["verify_k1"] = v_k1_pool
                            self.graphs["verify_k1"] = v_k1_graphs
                            self.graph_bs_list["verify_k1"] = v_k1_bs
                            # Skip verify_k2 capture when K1==K2 (same as k1).
                            if K2 < K1:
                                v_k2_gv, v_k2_pool, v_k2_graphs, v_k2_bs = capture_verify_cudagraph(
                                    self, k_plus_1=K2 + 1,
                                )
                                self.graph_vars["verify_k2"] = v_k2_gv
                                self.graph_pools["verify_k2"] = v_k2_pool
                                self.graphs["verify_k2"] = v_k2_graphs
                                self.graph_bs_list["verify_k2"] = v_k2_bs
                            print(f'[DUET split-K1K2] Captured draft glue_k1 CG '
                                  f'(K1+1={K1 + 1})'
                                  + (f' + glue_k2 CG (K2+1={K2 + 1})' if K2 < K1
                                     else ' (K2==K1, k2 SKIPPED)'),
                                  flush=True)
            if self.config.speculate and self.is_draft and self.config.draft_async and not self.batched_tree_enabled:
                fi_tree_decode_graph_vars, fi_tree_decode_graph_pool, fi_tree_decode_graphs, fi_tree_decode_graph_bs_list = capture_fi_tree_decode_cudagraph(self)  # fi tree decode cudagraph, draft only
                self.graph_vars["fi_tree_decode"] = fi_tree_decode_graph_vars
                self.graph_pools["fi_tree_decode"] = fi_tree_decode_graph_pool
                self.graphs["fi_tree_decode"] = fi_tree_decode_graphs
                self.graph_bs_list["fi_tree_decode"] = fi_tree_decode_graph_bs_list
                # DUET split-K1/K2 layout CudaGraphs are captured after _init_prealloc_buffers()
                # in DraftRunner.__init__, because the split layouts are created there.
            if self.config.speculate and self.is_draft and self.config.draft_async and self.config.use_eagle:
                glue_gv, glue_pool, glue_graphs, glue_bs_list = capture_glue_decode_cudagraph(self)
                self.graph_vars["glue_decode"] = glue_gv
                self.graph_pools["glue_decode"] = glue_pool
                self.graphs["glue_decode"] = glue_graphs
                self.graph_bs_list["glue_decode"] = glue_bs_list

        return model_type

    def exit(self, hard: bool = True):
        # Idempotent
        if getattr(self, "_exiting", False):
            return
        self._exiting = True
        if self.verbose:
            print(f"[ModelRunner] Exit start (rank={self.rank}, draft={self.is_draft}, hard={hard})", flush=True)
        # 1) Notify draft first (target rank 0 only)
        try:
            self.send_draft_exit_signal()
        except Exception:
            pass
        # 2) Best-effort local cleanup (no collectives; avoid group destroys in hard mode)
        try:
            if not self.enforce_eager and hasattr(self, "graphs"):
                del self.graphs
                if hasattr(self, "graph_pool"):
                    del self.graph_pool
            if hasattr(self, "verify_graphs"):
                del self.verify_graphs
            if hasattr(self, "verify_graph_pool"):
                del self.verify_graph_pool
            if hasattr(self, "glue_graphs"):
                del self.glue_graphs
            if hasattr(self, "glue_graph_pool"):
                del self.glue_graph_pool
        except Exception:
            pass
        # Close SHM on all ranks that have it
        try:
            if hasattr(self, "shm") and self.shm is not None:
                self.shm.close()
                if self.rank == 0:
                    try:
                        self.shm.unlink()
                    except Exception:
                        pass
        except Exception:
            pass
        # 3) Non-hard path: try to tear down process groups (may block, so do only if not hard)
        if not hard:
            try:
                if hasattr(self, "async_pg"):
                    dist.destroy_process_group(self.async_pg)
            except Exception:
                pass
            try:
                if self.world_size > 1 and hasattr(self, "tp_pg") and self.tp_pg is not None:
                    dist.destroy_process_group(self.tp_pg)
            except Exception:
                pass
            try:
                # Default group
                if self.world_size > 1 or (self.draft_async and self.is_draft):
                    dist.destroy_process_group()
            except Exception:
                pass
            return
        # 4) Hard path: do not destroy groups (avoid NCCL waits). Draft process can exit immediately.
        if self.is_draft:
            if self.verbose:
                print(f"[ModelRunner] Draft hard-exit", flush=True)
            os._exit(0)
        # Target ranks: let the process return if we're a worker (subprocess),
        # main rank will be force-exited by the engine after it joins children.
        if self.verbose:
            print(f"[ModelRunner] Exit complete (rank={self.rank})", flush=True)
        return

    def loop(self):
        while True:
            method_name, args = self.read_shm()
            self.call(method_name, *args)
            if method_name == "exit":
                break

    def recv_cmd(self):
        t = torch.empty(1, dtype=torch.int64, device=self.device)
        dist.recv(t, src=0, group=self.async_pg)
        return int(t.item())

    def recv_tensor(self, shape, dtype=torch.int64):
        t = torch.empty(shape, dtype=dtype, device=self.device)
        dist.recv(t, src=0, group=self.async_pg)
        return t
    
    def send_draft_exit_signal(self):
        """
        Best-effort: send cmd=2 to draft (async_pg) from TARGET rank 0.
        Safe to call multiple times.
        """
        if not (self.draft_async and not self.is_draft and self.rank == 0):
            return
        try:
            cmd = torch.tensor([2], dtype=torch.int64, device=self.device)
            dist.send(cmd, dst=self.draft_rank, group=self.async_pg)
        except Exception:
            pass
    def read_shm(self):
        assert self.world_size > 1 and self.rank
        self.event.wait()
        n = int.from_bytes(self.shm.buf[0:4], "little")
        method_name, *args = pickle.loads(self.shm.buf[4:n+4])
        self.event.clear()
        return method_name, args

    def write_shm(self, method_name, *args):
        assert self.world_size > 1 and not self.rank
        # 이슈 #22 (리뷰 2E): 단일 SHM 버퍼 — 모든 worker가 이전 명령을
        # 소비(read_shm에서 event.clear())하기 전에 덮어쓰면 명령 유실.
        # 소비-대기 후 기록 (평시 즉시 통과; commit+run처럼 스텝당 2회
        # call이 생긴 트리 경로에서 필수).
        for event in self.event:
            while event.is_set():
                time.sleep(0.0001)
        data = pickle.dumps([method_name, *args])
        n = len(data)
        assert n + 4 <= self.shm.size, f"SHM overflow: {n+4} > {self.shm.size}. Increase SHM buffer size."
        self.shm.buf[0:4] = n.to_bytes(4, "little")
        self.shm.buf[4:n+4] = data
        for event in self.event:
            event.set()

    def call(self, method_name, *args):
        if self.world_size > 1 and self.rank == 0:
            self.write_shm(method_name, *args)
        method = getattr(self, method_name, None)
        if method is None:
            raise AttributeError(f"Method '{method_name}' not found")
        return method(*args)

    def warmup_model(self):
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        max_num_batched_tokens, max_model_len = self.config.max_num_batched_tokens, self.config.max_model_len
        num_seqs = min(max_num_batched_tokens // max_model_len, self.config.max_num_seqs)
        seqs = [Sequence([0] * max_model_len) for _ in range(num_seqs)]
        
        hidden_states = None
        if self.config.use_eagle and self.is_draft:
            num_tokens = num_seqs * max_model_len
            d_model_target = self.config.d_model_target or 4096
            hidden_states = torch.zeros(num_tokens, 3 * d_model_target, dtype=self.hf_config.torch_dtype, device=self.device)
        
        self.run(seqs, True, hidden_states=hidden_states)
        torch.cuda.empty_cache()

    def _warmup_tree_proxy(self):
        """Warm the exact rank-0 tree proxy path before serving traffic.

        The exit replica and its topology-dependent Policy-B kernels are not
        exercised by the ordinary prefill warmup.  Without this pass the
        first real P2 tree hit pays lazy softmax/reduction/top-k setup on the
        request critical path.  Non-tree, draft, and non-rank-0 paths remain
        untouched.
        """
        cfg = self.config
        if (self.is_draft or self.rank != 0
                or not getattr(cfg, "duet_enabled", False)
                or not getattr(cfg, "duet_tree_enabled", False)
                or not getattr(cfg, "duet_exit_replica", False)
                or not hasattr(self, "_duet_lm_head_replica")
                or not self.tree_verify_wrappers):
            return

        from ssd.engine.helpers.p2_tree import warmup_tree_proxy_kernels

        # Reuse this stream in the live tree callback so stream creation and
        # allocator ownership are warmed as well as the kernels themselves.
        stream = getattr(self, "_duet_exit_stream", None)
        if stream is None:
            stream = torch.cuda.Stream(device=self.device)
            self._duet_exit_stream = stream

        # These are the production confidence-tree shapes.  Unknown future
        # buckets fall back to a breadth-first three-child tree followed by a
        # first-child backbone, preserving the same kernel classes.
        templates = {
            4: [-1, -1, -1, 0],
            6: [-1, -1, -1, 0, 3, 4],
            8: [-1, -1, -1, 0, 0, 1, 3, 6],
        }

        with torch.cuda.stream(stream):
            for nv in sorted(self.tree_verify_wrappers):
                par = list(templates.get(int(nv), []))
                if not par:
                    par = [-1] * min(3, int(nv))
                    while len(par) < int(nv):
                        par.append(max(0, len(par) - 3))
                sibling_count = {}
                sib = []
                for parent in par:
                    order = sibling_count.get(parent, 0)
                    sib.append(order)
                    sibling_count[parent] = order + 1

                r = int(nv) + 1
                hidden = torch.zeros(
                    r, self.hf_config.hidden_size,
                    dtype=self.hf_config.torch_dtype, device=self.device)
                normed = self.model.model.norm(hidden, None)
                exit_logits = torch.nn.functional.linear(
                    normed, self._duet_lm_head_replica)
                q_logits = torch.zeros(
                    int(nv), self.hf_config.vocab_size,
                    dtype=self.hf_config.torch_dtype, device=self.device)
                # A second pass also warms allocator reuse after the first
                # shape-specific kernel materialization.
                for _ in range(2):
                    warmup_tree_proxy_kernels(
                        exit_logits, q_logits, par, sib,
                        cfg.duet_proxy_wire_N)
        stream.synchronize()
        # Do not let temporary full-vocab buffers reduce KV-cache sizing.
        torch.cuda.empty_cache()
        print(f"[DUET tree] warmed proxy kernels "
              f"(buckets={sorted(self.tree_verify_wrappers)})", flush=True)

    def _warmup_tree_topology_gpu(self):
        """Compile the target-side GPU topology kernels before serving.

        Triton specializes on the live-node count and padded verify-row
        bucket.  Exercise every reachable live width once after the target
        verify graphs exist, writing only into their persistent input/mask
        buffers.  This prevents the first tree hit of a new width from paying
        JIT compilation on the request critical path.
        """
        if (os.environ.get("SSD_TREE_TOPOLOGY_GPU", "1") == "0"
                or self.is_draft
                or self.device.type != "cuda"):
            return
        graphs = getattr(self, "_tree_verify_cg", None)
        if not graphs:
            return

        from ssd.engine.helpers.tree_topology_gpu import (
            build_tree_verify_inputs_gpu_)

        buckets = sorted({int(key[0]) for key in graphs})
        max_valid = max(buckets)
        for valid in range(1, max_valid + 1):
            nv_b = next(bucket for bucket in buckets if bucket >= valid)
            cg = graphs[(nv_b, 1)]
            rows = nv_b + 1
            # A chain is a valid representative topology for every width;
            # runtime parent values do not affect the compiled kernel shape.
            parent = torch.arange(
                valid, dtype=torch.int64, device=self.device) - 1
            source_ids = torch.zeros(
                valid + 1, dtype=torch.int64, device=self.device)
            source_slots = torch.arange(
                valid + 1, dtype=torch.int32, device=self.device)
            prefix_len = 7
            kv_len = prefix_len + valid
            build_tree_verify_inputs_gpu_(
                parent,
                source_ids,
                source_slots,
                cg["bufs"]["input_ids"],
                cg["bufs"]["rope"],
                cg["bufs"]["slot_mapping"],
                cg["bufs"]["context_lens"],
                cg["wrapper"]._custom_mask_buf,
                valid=valid,
                rows=rows,
                pos0=prefix_len - 1,
                prefix_len=prefix_len,
                kv_len=kv_len,
            )
        torch.cuda.synchronize(self.device)
        print("[DUET tree] warmed GPU target topology "
              f"(valid=1..{max_valid}, buckets={buckets})", flush=True)

    def _capture_tree_proxy_graphs(self):
        """Build rank-0 target proxy graphs before the engine is ready.

        Verifier is constructed lazily by ``generate()``.  Capturing these
        graphs in ``Verifier.__init__`` therefore charged roughly seven
        seconds to the first request even though the kernels themselves were
        warmed.  Keep the persistent graph objects on ModelRunner and let
        every Verifier instance reuse them.  Chain K1/K2 graphs are prepared
        here as well: cache miss has no tree metadata and previously fell
        back to many eager Policy-B launches, which produced the long proxy
        bar seen in miss timelines.
        """
        self._tree_proxy_graphs_prebuilt = {}
        self._chain_proxy_graphs_prebuilt = {}
        if self.batched_tree_enabled:
            return
        cfg = self.config
        if (self.is_draft or self.rank != 0
                or self.device.type != "cuda"
                or not getattr(cfg, "duet_enabled", False)):
            return

        from ssd.engine.helpers.p2_tree import (
            ChainProxyCUDAGraph, TreeProxyCUDAGraph)
        if (os.environ.get("SSD_CHAIN_PROXY_GRAPH", "1") != "0"
                and not getattr(cfg, "duet_proxy_on_draft", False)
                and not getattr(cfg, "duet_exit_topm_gather", False)):
            widths = sorted({int(cfg.duet_phase1_k),
                             int(cfg.duet_phase2_k)})
            # One proxy wire schema for all requests.  A P1-tree hit also
            # needs scores even when P2 tree generation is disabled, so
            # chain and tree callbacks both pack them whenever either phase
            # can produce a tree.
            pack_scores = getattr(cfg, "duet_tree_enabled", False)
            for k in widths:
                self._chain_proxy_graphs_prebuilt[k] = ChainProxyCUDAGraph(
                    k=k,
                    vocab_size=cfg.hf_config.vocab_size,
                    top_k=cfg.duet_proxy_top_k,
                    wire_n=cfg.duet_proxy_wire_N,
                    pack_scores=pack_scores,
                    dtype=cfg.hf_config.torch_dtype,
                    device=self.device)
            print("[DUET] captured target chain proxy graphs "
                  f"(K={widths})", flush=True)

        if (os.environ.get("SSD_TREE_PROXY_GRAPH", "1") == "0"
                or not getattr(cfg, "duet_tree_enabled", False)
                or not self.tree_verify_wrappers):
            return
        max_valid = max(self.tree_verify_wrappers)
        tree_depth_steps = max(
            int(cfg.duet_phase2_k),
            (int(cfg.duet_phase1_k)
             if cfg.duet_p1_tree_policy == "on" else 0))
        for nv in range(1, int(max_valid) + 1):
            graph = TreeProxyCUDAGraph(
                nv=nv,
                vocab_size=cfg.hf_config.vocab_size,
                wire_n=cfg.duet_proxy_wire_N,
                depth_steps=tree_depth_steps,
                top_k=cfg.duet_proxy_top_k,
                dtype=cfg.hf_config.torch_dtype,
                device=self.device)
            # Compile and initialize the GPU topology packer for this exact
            # proxy bucket.  Live requests overwrite these representative
            # chain values before replay.
            if os.environ.get("SSD_TREE_TOPOLOGY_GPU", "1") != "0":
                graph.prepare_topology_device(
                    torch.arange(
                        nv, dtype=torch.int64, device=self.device) - 1,
                    torch.zeros(nv, dtype=torch.int64, device=self.device),
                )
            self._tree_proxy_graphs_prebuilt[nv] = graph
        if os.environ.get("SSD_TREE_TOPOLOGY_GPU", "1") != "0":
            torch.cuda.synchronize(self.device)
        print("[DUET tree] captured target proxy graphs "
              f"(buckets={sorted(self._tree_proxy_graphs_prebuilt)})",
              flush=True)

    def allocate_kv_cache(self):
        print(f'inside allocate_kv_cache -- ', flush=True)
        config = self.config
        hf_config = self.hf_config
        
        # Simplify: just look at free memory on the GPU, and allocate up to gpu_memory_utilization * free.
        free, _ = torch.cuda.mem_get_info()
        num_kv_heads = hf_config.num_key_value_heads // self.num_tp_gpus
        block_bytes = (
            2
            * hf_config.num_hidden_layers
            * self.block_size
            * num_kv_heads
            * hf_config.head_dim
            * hf_config.torch_dtype.itemsize
        )
        usable_bytes = free * config.gpu_memory_utilization

        if self.is_draft and self.draft_async:
            B = config.max_num_seqs          # max concurrent sequences
            K = config.speculate_k           # speculative steps
            F = config.async_fan_out         # branches per step
            V = hf_config.vocab_size
            dtype_size = hf_config.torch_dtype.itemsize
            # Total forks = B * (K+1) * F, each fork stores (K+1)*V logits of size dtype_size
            reserved_bytes = B * (K + 1) * F * (K + 1) * V * dtype_size
            usable_bytes = max(usable_bytes - reserved_bytes, 0)
            assert usable_bytes > 0, "ERROR: Not enough memory for draft KV cache after accounting for tree_cache for logits storage"

        config.num_kvcache_blocks = int(usable_bytes) // block_bytes
        if self.verbose:
            print(f'KV CACHE ALLOCATION for {"TARGET" if not self.is_draft else "DRAFT"} model', flush=True)
            print(f' free={free/1e9:.2f}GB, util={config.gpu_memory_utilization:.2f}', flush=True)
            print(f' block_bytes={block_bytes/1e9:.2f}GB,'
            + f' num_kvcache_blocks={config.num_kvcache_blocks}', flush=True)   
        
        assert config.num_kvcache_blocks > 0, "KV cache too big for free memory!"

        self.kv_cache = torch.zeros( 
            2,
            hf_config.num_hidden_layers,
            config.num_kvcache_blocks,
            self.block_size,
            num_kv_heads,
            hf_config.head_dim, 
        )
        
        print(f"allocate_kv_cache(): kv_cache shape = {self.kv_cache.shape}", flush=True)
        layer_id = 0
        for module in self.model.modules():
            if hasattr(module, "k_cache") and hasattr(module, "v_cache"):
                module.k_cache = self.kv_cache[0, layer_id]
                module.v_cache = self.kv_cache[1, layer_id]
                if self.is_draft and self.draft_async and not self.enforce_eager:
                    module.prefill_wrappers = self.prefill_wrappers
                elif self.is_draft and self.draft_async and self.enforce_eager:
                    module.only_prefill_wrapper = self.only_prefill_wrapper # this will make it not None so it can be used on fwd
                layer_id += 1

    
    def prepare_prefill(self, seqs: list[Sequence]):
        input_ids, positions, cu_seqlens_q, cu_seqlens_k, max_seqlen_q, max_seqlen_k, slot_mapping = \
            prepare_prefill_tensors_from_seqs(seqs, self.block_size, self.is_draft) # if one big input ids, how is attn mask handled? via cu_seqlens_q/k? 

        block_tables = None
        if cu_seqlens_k[-1] > cu_seqlens_q[-1]:    # prefix cache
            block_tables = prepare_block_tables_from_seqs(
                seqs, self.is_draft)
        
        set_context(is_prefill=True, cu_seqlens_q=cu_seqlens_q, cu_seqlens_k=cu_seqlens_k, max_seqlen_q=max_seqlen_q,
                    max_seqlen_k=max_seqlen_k, slot_mapping=slot_mapping, context_lens=None, block_tables=block_tables)
        return input_ids, positions
    
    def prepare_decode(self, seqs: list[Sequence], verify: bool = False):
        # v1 hybrid: verify shape varies per step. Uses _duet_step_lookahead
        # set by Verifier (= valid_k of the matched cache row). Default for
        # non-hybrid path is config.speculate_k.
        if verify:
            verify_k = getattr(self, "_duet_step_lookahead", self.config.speculate_k)
        else:
            verify_k = -1
        input_ids, positions, slot_mapping, context_lens = \
            prepare_decode_tensors_from_seqs(seqs, self.block_size, self.is_draft, verify, verify_k)


        block_tables = prepare_block_tables_from_seqs(seqs, self.is_draft) # if verify, set cu_seqlens_q as well

        if verify: ### what path does glue decode take? trace it.
            # this had [not draft and draft_async] condn before
            cu_seqlens_q = torch.zeros(len(seqs) + 1, dtype=torch.int32, device=self.device)
            seqlen_q = torch.full((len(seqs),), verify_k + 1, dtype=torch.int32, device=self.device)
            cu_seqlens_q[1:] = torch.cumsum(seqlen_q, dim=0)
            set_context(is_prefill=False, cu_seqlens_q=cu_seqlens_q, cu_seqlens_k=None,
                       max_seqlen_q=verify_k + 1, max_seqlen_k=0,
                       slot_mapping=slot_mapping, context_lens=context_lens,
                       block_tables=block_tables)
        else: # sq_decode path, draft (sync spec) or target (normal)
            set_context(is_prefill=False, cu_seqlens_q=None, cu_seqlens_k=None, 
                       max_seqlen_q=0, max_seqlen_k=0, slot_mapping=slot_mapping, 
                       context_lens=context_lens, block_tables=block_tables)
        
        return input_ids, positions

    def prepare_sample(self, seqs: list[Sequence]):
        temperatures = []
        for seq in seqs:
            if self.is_draft and seq.draft_temperature is not None:
                temperatures.append(seq.draft_temperature)
            else:
                temperatures.append(seq.temperature)
        temperatures = torch.tensor(temperatures, dtype=torch.float32, pin_memory=True).cuda(non_blocking=True)
        return temperatures

    def _first_attn_module(self):
        """Return one attention layer for TP-local head geometry."""
        cached = getattr(self, "_attn_mod", None)
        if cached is not None:
            return cached
        from ssd.layers.attention import Attention
        for module in self.model.modules():
            if isinstance(module, Attention):
                self._attn_mod = module
                return module
        raise RuntimeError("model has no SSD Attention module")

    def _plan_flashinfer_dense_attention(self, is_prefill: bool) -> None:
        """Plan the sm_120 eager attention wrapper once per model call."""
        from ssd.layers.fi_attn import (
            get_fi_backend,
            use_flashinfer_attention,
        )
        if not use_flashinfer_attention(self.device):
            return

        context = get_context()
        attn = self._first_attn_module()
        backend = get_fi_backend(self.device)
        backend.cg_cur = None
        common = (
            attn.num_heads,
            attn.num_kv_heads,
            attn.head_dim,
            attn.scale,
            self.hf_config.torch_dtype,
        )
        if is_prefill:
            if context.block_tables is not None:
                kv_lens = (
                    context.cu_seqlens_k[1:] - context.cu_seqlens_k[:-1]
                ).to(torch.int32)
                backend.plan_paged(
                    context.cu_seqlens_q,
                    context.block_tables,
                    kv_lens,
                    self.block_size,
                    *common,
                )
            else:
                backend.plan_prefill_ragged(
                    context.cu_seqlens_q,
                    context.cu_seqlens_k,
                    *common,
                )
        elif context.cu_seqlens_q is not None:
            backend.plan_paged(
                context.cu_seqlens_q,
                context.block_tables,
                context.context_lens,
                self.block_size,
                *common,
            )
        else:
            backend.plan_decode(
                context.block_tables,
                context.context_lens,
                self.block_size,
                *common,
            )

    def eager_tree_decode_plan(self, input_ids, positions, step, cache_hits):
        """Plan FlashInfer for tree decode in eager mode"""
        assert self.is_draft and self.config.draft_async, "ERROR in eager_tree_decode_plan: not a draft async model"
        context = get_context()
        
        K, F = self.config.speculate_k, self.config.async_fan_out
        # MQ_LEN = F * (K+1)
        MQ_LEN = self.config.MQ_LEN
        flat_batch_size = input_ids.size(0) 
        B = flat_batch_size // MQ_LEN # [N] tokens = B * sum(fan_out_list)
        
        # Convert block_tables to FlashInfer format
        block_tables = context.block_tables # [B, M]
        context_lens = context.context_lens # [B]
        
        counts = (context_lens + self.block_size - 1) // self.block_size # [B]
        kv_indptr = torch.cat([torch.tensor([0], device=block_tables.device),
                               counts.cumsum(dim=0)]).to(torch.int32)  
        mask = torch.arange(block_tables.size(1), device=block_tables.device)[None, :] < counts[:, None]
        kv_indices = block_tables[mask]                    # flattened page ids
        
        # Last-page actual token count per request
        kv_last_page_len = (context_lens % self.block_size)
        kv_last_page_len[kv_last_page_len == 0] = self.block_size
        kv_last_page_len = kv_last_page_len.to(torch.int32)
        cu_seqlens_q = torch.arange(B + 1, device=self.device, dtype=torch.int32) * MQ_LEN # assumes same MQ_LEN across batch dimension 
        custom_mask = get_custom_mask(self.config, context_lens, step, K, F, B, device=self.device, cache_hits=cache_hits)
        
        self.only_prefill_wrapper.plan(
            cu_seqlens_q,
            kv_indptr,
            kv_indices,
            kv_last_page_len,
            self.hf_config.num_attention_heads,
            self.hf_config.num_key_value_heads,
            self.hf_config.head_dim,
            self.block_size,
            custom_mask=custom_mask,
            q_data_type=self.hf_config.torch_dtype,
            kv_data_type=self.hf_config.torch_dtype,
        )

    @torch.inference_mode()
    def run_model(self, input_ids: torch.Tensor, positions: torch.Tensor, is_prefill: bool, last_only: bool = True, tree_decode_step: int = -1, cache_hits: torch.Tensor | None = None, hidden_states: torch.Tensor | None = None):
        is_tree_decode = self.is_draft and self.config.draft_async and tree_decode_step >= 0
        is_mq_kp1 = self.config.speculate and not last_only
        spec_and_dec = not is_prefill and self.config.speculate

        assert not (is_prefill and not last_only), "ERROR in run_model: is_prefill and not last_only"
        
        if is_prefill or self.enforce_eager:
            if is_tree_decode:
                self.eager_tree_decode_plan(input_ids, positions, tree_decode_step, cache_hits)
            else:
                self._plan_flashinfer_dense_attention(is_prefill)
            
            if self.config.use_eagle: 
                if self.is_draft:
                    assert hidden_states is not None, "hidden_states required for EAGLE draft"
                    assert isinstance(self.model, Eagle3DraftForCausalLM)
                    prenorm = self.model(input_ids, positions, hidden_states)
                    logits = self.model.compute_logits(prenorm, last_only)
                    return logits, prenorm  # return prenorm as conditioning vector for next iteration
                else: # target gets outputs and hidden states
                    outputs, eagle_acts = self.model(input_ids, positions) # target fwd when eagle enabled hooks into activations for eagle conditioning
                    logits = self.model.compute_logits(outputs, last_only)
                    return logits, eagle_acts  # return eagle_acts as conditioning vector for draft
            else: 
                outputs = self.model(input_ids, positions)
                logits = self.model.compute_logits(outputs, last_only)
                return logits 

        elif is_tree_decode:
            if self.config.duet_enabled:
                _ctx = get_context()
                # Use runtime layout from context if available (Policy A dynamic fan_out)
                if _ctx.active_layout is not None:
                    _tree_layout = _ctx.active_layout
                    _tree_graph_key = _tree_layout.graph_key
                else:
                    _tree_graph_key = "fi_tree_decode"
                    _tree_layout = None
                return run_fi_tree_decode_cudagraph(self, input_ids, positions, last_only, self.graph_vars[_tree_graph_key], tree_decode_step, cache_hits, hidden_states=hidden_states, layout=_tree_layout)
            else:
                return run_fi_tree_decode_cudagraph(self, input_ids, positions, last_only, self.graph_vars["fi_tree_decode"], tree_decode_step, cache_hits, hidden_states=hidden_states)
        elif is_mq_kp1 and hidden_states is not None and "glue_decode" in self.graph_vars:
            # EAGLE draft glue decode with 2K+1 per seq
            return run_glue_decode_cudagraph(self, input_ids, positions, last_only, self.graph_vars["glue_decode"], hidden_states)
        elif is_mq_kp1 and self.config.duet_enabled and not self.is_draft \
                and "duet_verify_k1" in self.graph_vars:
            # ---- Split-only K1/K2 mode: target verify dispatch ----
            # Buckets are {duet_verify_k1, duet_verify_k2}. The hybrid
            # duet_verify_long/short and legacy duet_verify buckets were
            # removed (2026-07).
            # T3.4-b4: 트리 verify — 메타가 오면 CG 버킷 대신 eager
            # 분할 forward + FlashInfer tree wrapper.
            if getattr(self, "_duet_tree_meta", None) is not None:
                return self._run_tree_verify(input_ids, positions, last_only)
            return self._run_split_k1k2_target_verify(
                input_ids, positions, last_only,
            )
        elif is_mq_kp1: # verify or non-EAGLE glue decode, "verify" ~ mq decode of len K+1
            # ---- Split-only K1/K2 mode: draft glue dispatch ----
            # SSD_FORCE_SPLIT_K1K2 → buckets are {verify_k1, verify_k2}.
            # Independent dispatch helper so this branch never falls back to
            # hybrid's verify/verify_short.
            if (
                self.is_draft
                and os.environ.get("SSD_FORCE_SPLIT_K1K2", "0") == "1"
                and self.config.duet_phase1_k is not None
                and "verify_k1" in self.graph_vars
            ):
                # K1==K2: only verify_k1 captured; helper routes both lookaheads to it.
                return self._run_split_k1k2_glue(
                    input_ids, positions, last_only,
                )
            return run_verify_cudagraph(self, input_ids, positions, last_only, self.graph_vars["verify"], bucket="verify")
        else: # draft decoding in sync spec or JIT single-token decode
            return run_decode_cudagraph(self, input_ids, positions, last_only, self.graph_vars["decode"], hidden_states=hidden_states)

    # ============================================================
    # Split-only K1/K2 mode: independent dispatch helpers.
    # Per docs/duet/04-split-k1k2-design.md.
    # valid_k space = {K1, K2}; K_max = max(K1, K2).
    # ============================================================
    def _run_split_k1k2_glue(self, input_ids, positions, last_only):
        """Draft-side glue dispatch in split-only K1/K2 mode (K2 <= K1).

        Reads context.glue_valid_k. Picks verify_k1 (K1+1) or verify_k2 (K2+1).
        At K1==K2, verify_k2 is not captured — both vk values route to verify_k1.
        First step / cache-empty default = K_max = K1.
        """
        K1 = self.config.duet_phase1_k
        K2 = self.config.duet_phase2_k
        _ctx = get_context()
        _vk = getattr(_ctx, "glue_valid_k", None)
        if _vk is None:
            _vk = K1  # K_max default
        if _vk not in (K1, K2):
            raise RuntimeError(
                f"split-K1K2 glue: unexpected valid_k={_vk}; "
                f"expected K1={K1} or K2={K2}")
        # K1==K2: verify_k2 not captured — collapse to verify_k1.
        bucket = "verify_k2" if (_vk == K2 and K2 < K1) else "verify_k1"
        return run_verify_cudagraph(
            self, input_ids, positions, last_only,
            self.graph_vars[bucket], bucket=bucket,
        )

    def _run_split_k1k2_target_verify(self, input_ids, positions, last_only):
        """Target-side verify dispatch in split-only K1/K2 mode (K2 <= K1).

        Reads self._duet_step_lookahead (Verifier sets it from speculate_result.
        valid_k). At K1==K2, duet_verify_k2 is not captured — both lookaheads
        route to duet_verify_k1.
        """
        K1 = self.config.duet_phase1_k
        K2 = self.config.duet_phase2_k
        _step_lookahead = getattr(self, "_duet_step_lookahead", K1)
        if _step_lookahead not in (K1, K2):
            raise RuntimeError(
                "split-K1K2 target verify: unexpected lookahead="
                f"{_step_lookahead}; expected K1={K1} or K2={K2}")
        bucket = "duet_verify_k2" if (_step_lookahead == K2 and K2 < K1) else "duet_verify_k1"
        return run_duet_verify_cudagraph(
            self, input_ids, positions, last_only,
            self.graph_vars[bucket],
            duet_proxy_fn=self._duet_proxy_fn,
            bucket=bucket,
        )

    @torch.inference_mode()
    def warm_batched_tree_forward(self, batch, width, pages):
        from ssd.engine.helpers.batch_tree_forward import BatchedTreeForward
        if not hasattr(self, '_batched_tree_forward'):
            self._batched_tree_forward=BatchedTreeForward(self, split=True)
        self._batched_tree_forward.capture(batch,width,pages)

    @torch.inference_mode()
    def run_batched_tree(self, rows, width):
        from ssd.engine.helpers.batch_tree_forward import BatchedTreeForward
        if not hasattr(self, '_batched_tree_forward'):
            self._batched_tree_forward = BatchedTreeForward(self, split=True)
        return self._batched_tree_forward.run(rows, width, self._duet_proxy_fn)

    @torch.inference_mode()
    def commit_tree_kv(self, src_slots, dst_slots):
        """T3.4-b6-3 — 수락 경로 KV의 scratch→canonical 셀 복사.

        rope는 KV에 이미 구워져 있어 (트리 rope = pos0+1+depth = 경로
        canonical 위치와 동일) 셀 이동만으로 재실체화가 완성된다
        (commit_copy_plan의 실행부). 겹침 대비 gather 후 scatter.
        target은 verifier가 call()로 전 rank에 브로드캐스트, draft는
        로컬 호출 (TP1). B=1: SHM 명령 순서가 다음 run()보다 선행을
        보장 — ack 불요 (B>1 tree 게이트 OFF).
        """
        if not src_slots:
            return
        kc = self.kv_cache
        flat = kc.view(kc.shape[0], kc.shape[1], -1, kc.shape[4],
                       kc.shape[5])
        src = torch.tensor(src_slots, dtype=torch.int64, device=kc.device)
        dst = torch.tensor(dst_slots, dtype=torch.int64, device=kc.device)
        tmp = flat[:, :, src].clone()
        flat[:, :, dst] = tmp

    def _run_tree_verify(self, input_ids, positions, last_only):
        """P2-tree verify (T3.4-b4). B=1 전용, v1은 eager 분할 forward.

        창 = [rec | 뷰 노드(생성 순서)] — extend/prepare가 만든 선형
        scratch 셀·slot은 그대로 쓰고 (리뷰4 row 계약), rope만
        pos0+1+depth(노드)로 덮어쓴다. attention은 FlashInfer tree
        wrapper (조상 custom mask; T3.1b의 명시 TREE_VERIFY 분기).
        exit-proxy는 CG 경로의 mid-block 게이트(replica/topm/plain)를
        eager로 미러 — 행 축이 곧 노드 축이라 proxy가 자연히 노드별
        p^E가 된다. 행 수는 N_v bucket으로 패딩 (slot -1, prefix-only
        mask) — 이후 CG capture와 동일 shape 유지.
        """
        from ssd.engine.helpers.p2_tree import (
            pack_tree_verify_mask_direct, parse_tree_ints,
            validate_tree_ints)
        from ssd.engine.helpers.tree_topology_gpu import (
            build_tree_verify_inputs_gpu_)
        from ssd.engine.helpers.cudagraph_helpers import (
            duet_record, duet_close, _duet_exit_topm_gather,
            update_tree_verify_graph_buffers)
        cfg = self.config
        # Include the host-side topology reconstruction and FlashInfer plan
        # in the target timeline.  Previously this work sat in an unlabeled
        # gap immediately before graph_pre and was easy to mistake for proxy
        # communication.
        _ev_setup = duet_record("verify_setup")
        _ev_meta = duet_record("tree_verify_meta_cpu")
        nv = int(cfg.duet_tree_wire_nodes)
        # The SHM command is already an ordinary CPU list.  Re-wrapping it
        # as a torch tensor allocated storage every tree hit and then all
        # validation below immediately converted its scalar fields back to
        # Python ints.  parse/validate intentionally accept both lists and
        # tensors, so keep this boundary CPU-native.
        ti = parse_tree_ints(self._duet_tree_meta, nv)
        # Every TP rank receives the same metadata through SHM and performs
        # the same check before entering model collectives.  A corrupt tree
        # therefore fails coherently instead of leaving only rank 0 in the
        # acceptance path while its peers wait forever.
        validate_tree_ints(
            ti, nv, cfg.hf_config.vocab_size,
            sibling_capacity=cfg.duet_tree_c_tensor)
        valid = int(ti["valid"])
        n_rows = valid + 1
        assert input_ids.shape[0] == n_rows, (
            f"tree verify rows {input_ids.shape[0]} != valid+1 {n_rows}")
        context = get_context()
        kv_len = int(context.context_lens[0])
        # prepare_decode appends exactly valid speculative scratch rows.  Derive
        # the recovery position from that already materialised KV length and
        # avoid a separate GPU scalar read of positions[0].
        pos0 = kv_len - valid - 1
        if pos0 < 0:
            raise RuntimeError(
                f"tree verify invalid KV geometry: kv_len={kv_len} "
                f"valid={valid}")
        duet_close("tree_verify_meta_cpu", _ev_meta)

        # Bucket selection is host-only.  Row padding, depth/RoPE derivation,
        # and packed ancestor mask construction move to one fused GPU kernel.
        _ev_mask = duet_record("tree_verify_mask_prepare")
        _buckets = sorted(self.tree_verify_wrappers.keys())
        nv_b = next(b for b in _buckets if b + 1 >= n_rows)
        r_b = nv_b + 1

        bs = self.block_size
        n_blocks = (kv_len + bs - 1) // bs
        kv_indices = context.block_tables[0, :n_blocks].to(torch.int32)
        last_len = kv_len % bs
        last_len = bs if last_len == 0 else last_len
        # FlashInfer plan() copies these three tiny arrays back to the host
        # to select a kernel schedule.  Creating them on CUDA forced three
        # needless DtoH synchronizations after mask preparation.  Reuse CPU
        # buffers by verify width; page ids themselves remain on CUDA.
        _plan_host = getattr(self, "_tree_verify_plan_host", None)
        if _plan_host is None:
            _plan_host = self._tree_verify_plan_host = {}
        _ph = _plan_host.get(nv_b)
        if _ph is None:
            _ph = {
                "qo": torch.tensor([0, r_b], dtype=torch.int32),
                "kv": torch.empty(2, dtype=torch.int32),
                "last": torch.empty(1, dtype=torch.int32),
                "mask": torch.empty(2, dtype=torch.int32),
                "klen": torch.empty(1, dtype=torch.int32),
            }
            _plan_host[nv_b] = _ph
        _ph["kv"][0] = 0
        _ph["kv"][1] = n_blocks
        _ph["last"][0] = last_len
        _ph["mask"][0] = 0
        _ph["mask"][1] = r_b * kv_len
        _ph["klen"][0] = kv_len
        qo_indptr = _ph["qo"]
        kv_indptr = _ph["kv"]
        kv_last_page_len = _ph["last"]
        # A captured FlashInfer plan is valid only for its page-count shape.
        # Select that graph first.  The final page length and packed mask stay
        # exact: treating the unwritten page tail as a masked canvas can leak
        # non-finite/stale KV values through fused attention arithmetic.
        _cg = None
        if os.environ.get("SSD_TREE_VERIFY_EAGER", "0") != "1":
            _cg = getattr(self, "_tree_verify_cg", {}).get(
                (nv_b, n_blocks))
        _gpu_topology = (
            os.environ.get("SSD_TREE_TOPOLOGY_GPU", "1") != "0"
            and _cg is not None
            and self.device.type == "cuda"
        )
        if _gpu_topology:
            bufs = _cg["bufs"]
            wcg = _cg["wrapper"]
            _wire_gpu = getattr(self, "_duet_tree_wire_gpu_source", None)
            if (not torch.is_tensor(_wire_gpu)
                    or _wire_gpu.device != self.device
                    or _wire_gpu.numel() < 3 + 4 * nv):
                # TP followers receive a NumPy/list wire through SHM.  NumPy
                # shares its host storage with as_tensor, so this is one H2D
                # copy and no derived CPU topology allocation.
                _wire_cpu = torch.as_tensor(
                    self._duet_tree_meta, dtype=torch.int64)
                if _wire_cpu.numel() != self._tree_wire_device.numel():
                    raise RuntimeError(
                        "tree wire length mismatch: "
                        f"got={_wire_cpu.numel()} "
                        f"expected={self._tree_wire_device.numel()}")
                self._tree_wire_device.copy_(_wire_cpu, non_blocking=True)
                _wire_gpu = self._tree_wire_device
            _parent_gpu = _wire_gpu[3 + nv:3 + 2 * nv]
            _mask_numel = build_tree_verify_inputs_gpu_(
                _parent_gpu,
                input_ids,
                context.slot_mapping,
                bufs["input_ids"],
                bufs["rope"],
                bufs["slot_mapping"],
                bufs["context_lens"],
                wcg._custom_mask_buf,
                valid=valid,
                rows=r_b,
                pos0=pos0,
                prefix_len=pos0 + 1,
                kv_len=kv_len,
            )
            input_ids = bufs["input_ids"]
            rope = bufs["rope"]
            slot_mapping = bufs["slot_mapping"]
            _packed_mask = None
        else:
            # Correctness/diagnostic fallback: retain the established CPU
            # topology and NumPy packer for eager verify and A/B testing.
            par = ti["parent_local"]
            depths = [0] * valid
            anc = [[] for _ in range(valid)]
            for j in range(valid):
                p = int(par[j])
                if p >= 0:
                    depths[j] = depths[p] + 1
                    anc[j] = anc[p] + [p]
            if r_b > n_rows:
                pad = r_b - n_rows
                input_ids = torch.cat([input_ids, torch.zeros(
                    pad, dtype=input_ids.dtype, device=input_ids.device)])
                slot_mapping = torch.cat([
                    context.slot_mapping, torch.full(
                        (pad,), -1, dtype=context.slot_mapping.dtype,
                        device=context.slot_mapping.device)])
            else:
                slot_mapping = context.slot_mapping
            rope = torch.full((r_b,), pos0, dtype=positions.dtype,
                              device=positions.device)
            if valid:
                rope[1:n_rows] = pos0 + 1 + torch.tensor(
                    depths, dtype=positions.dtype, device=positions.device)
            _packed_mask = pack_tree_verify_mask_direct(
                anc, valid, r_b, pos0 + 1, kv_len)
            _mask_numel = _packed_mask.numel()
        _tp = max(1, self.num_tp_gpus)     # KV 할당(:896)과 동일한 분모
        duet_close("tree_verify_mask_prepare", _ev_mask)

        # The replica side stream reads capture-owned exit buffers.  Do not
        # let the next tree replay overwrite them before the prior callback
        # has finished; normally this event is already complete and the wait
        # is a no-op.
        if getattr(cfg, "duet_exit_replica", False):
            _prev_done = getattr(self, "_duet_exit_done_ev", None)
            if _prev_done is not None:
                torch.cuda.current_stream().wait_event(_prev_done)

        # === CG replay 경로 (T3.2 capture 존재 + eager 강제 아님) ===
        if _cg is not None:
            bufs = _cg["bufs"]
            wcg = _cg["wrapper"]
            if not _gpu_topology:
                _ev_copy = duet_record("tree_verify_input_copy")
                bufs["input_ids"].copy_(input_ids)
                bufs["rope"].copy_(rope)
                bufs["slot_mapping"].copy_(slot_mapping)
                bufs["context_lens"][0] = kv_len
                duet_close("tree_verify_input_copy", _ev_copy)
            # 이슈 #18: prepare_decode의 체인-verify context(cu_seqlens_q
            # 설정)가 남아 있으면 lm_head가 [1, rows, V] 3-D를 반환해
            # pad 절단이 무력화된다 (rows=1 관측). eager 분기와 동일하게
            # cu_seqlens_q 없는 decode context로 교체 — lm_head는 flat
            # [rows, V] 경로를 탄다 (replay 자체는 context 무관).
            set_context(
                is_prefill=False,
                slot_mapping=slot_mapping,
                context_lens=context.context_lens,
                block_tables=context.block_tables,
            )
            _ev_plan = duet_record("tree_verify_attention_buffers")
            # Graph launch geometry was captured for this exact page count;
            # the helper installs the request's real last-page length, page
            # ids and exact-length packed mask.
            update_tree_verify_graph_buffers(
                wcg, kv_indices, _packed_mask, _ph,
                mask_numel=_mask_numel)
            duet_close("tree_verify_attention_buffers", _ev_plan)
            duet_close("verify_setup", _ev_setup)
            _ev = duet_record("graph_pre")
            _cg["pre"].replay()
            duet_close("graph_pre", _ev)
            hs = bufs["exit_hidden"]
            res = bufs["exit_residual"]
        else:
            # eager 폴백: CG-제약 없는 지연-생성 wrapper
            w = getattr(self, "_tree_eager_wrapper", None)
            if w is None:
                import flashinfer
                w = flashinfer.BatchPrefillWithPagedKVCacheWrapper(
                    self._tree_workspace, "NHD")
                self._tree_eager_wrapper = w
            w.plan(
                qo_indptr, kv_indptr, kv_indices, kv_last_page_len,
                max(1, self.hf_config.num_attention_heads // _tp),
                max(1, self.hf_config.num_key_value_heads // _tp),
                self.hf_config.head_dim, bs,
                packed_custom_mask=_packed_mask.to(self.device),
                q_data_type=self.hf_config.torch_dtype,
                kv_data_type=self.hf_config.torch_dtype,
            )
            set_context(
                is_prefill=False,
                slot_mapping=slot_mapping,
                context_lens=context.context_lens,
                block_tables=context.block_tables,
                tree_verify_wrapper=w,
            )
            duet_close("verify_setup", _ev_setup)

            # === eager 분할 forward: pre → exit-proxy → post ===
            _ev = duet_record("graph_pre")
            hs, res = self.model(input_ids, rope,
                                 end_layer=cfg.duet_exit_layer + 1)
            duet_close("graph_pre", _ev)
        exit_layer = cfg.duet_exit_layer

        duet_proxy_fn = self._duet_proxy_fn
        _replica = getattr(self, "_duet_lm_head_replica", None)
        # 이슈 #12: exit-proxy에는 패딩 행이 새면 안 된다 —
        # _compute_and_send_proxy가 [1, vk+1, V]로 view하므로 반드시
        # n_rows(=valid+1)로 절단해 전달 (collective 참여 shape은 전
        # rank 동일한 n_rows 기준).
        if getattr(cfg, "duet_exit_replica", False):
            # Rank-0 replica work belongs on the same side stream as the
            # chain verifier.  The old tree path ran lm_head + Policy-B +
            # blocking send inline here, serializing graph_post by ~4ms.
            # The exit replica runs on a side stream.  Recording both events
            # on the default stream (the old ``exit_logits`` span) measured
            # launch/stream contention rather than the actual replica work.
            # Keep a tiny default-stream launch span and record the real
            # norm+lm_head+Policy-B+send interval on the side stream itself.
            _ev_el = duet_record("exit_proxy_launch")
            if duet_proxy_fn is not None and _replica is not None:
                _es = getattr(self, "_duet_exit_stream", None)
                if _es is None:
                    _es = torch.cuda.Stream(device=_replica.device)
                    self._duet_exit_stream = _es
                _ready = torch.cuda.Event()
                _ready.record()
                with torch.cuda.stream(_es):
                    _es.wait_event(_ready)
                    _ev_side = duet_record("exit_proxy_side")
                    normed = self.model.model.norm(
                        (hs + res)[:n_rows], None)
                    exit_logits = torch.nn.functional.linear(
                        normed, _replica)
                    duet_proxy_fn(exit_logits, 1)
                    duet_close("exit_proxy_side", _ev_side)
                _done = torch.cuda.Event()
                _done.record(_es)
                self._duet_exit_done_ev = _done
            duet_close("exit_proxy_launch", _ev_el)
        else:
            _ev_el = duet_record("exit_logits")
            normed = self.model.model.norm((hs + res)[:n_rows], None)
            if getattr(cfg, "duet_exit_topm_gather", False):
                exit_logits = _duet_exit_topm_gather(
                    self, normed, input_ids[:n_rows], cfg.duet_proxy_topm)
            else:
                # 전 rank compute_logits (gather 참여) — rank0만 실값
                exit_logits = self.model.compute_logits(
                    normed, last_only=False)
            duet_close("exit_logits", _ev_el)
            _ev_ps = duet_record("exit_proxy_launch")
            if duet_proxy_fn is not None:
                _proxy_stream = getattr(self, "_duet_proxy_stream", None)
                if (_proxy_stream is None
                        and os.environ.get("SSD_PROXY_STREAM", "0") == "1"):
                    _proxy_stream = torch.cuda.Stream(device=self.device)
                    self._duet_proxy_stream = _proxy_stream
                if _proxy_stream is not None:
                    if exit_logits is not None and torch.is_tensor(exit_logits):
                        exit_logits.record_stream(_proxy_stream)
                    _ready = torch.cuda.Event()
                    _ready.record()
                    with torch.cuda.stream(_proxy_stream):
                        _proxy_stream.wait_event(_ready)
                        _ev_side = duet_record("exit_proxy_side")
                        duet_proxy_fn(exit_logits, 1)
                        duet_close("exit_proxy_side", _ev_side)
                else:
                    _ev_side = duet_record("exit_proxy_side")
                    duet_proxy_fn(exit_logits, 1)
                    duet_close("exit_proxy_side", _ev_side)
            duet_close("exit_proxy_launch", _ev_ps)

        _ev = duet_record("graph_post")
        if _cg is not None:
            _cg["post"].replay()
            out = _cg["bufs"]["outputs"]
        else:
            out = self.model(input_ids, rope, start_layer=exit_layer + 1,
                             init_hidden_states=hs, init_residual=res)
            if isinstance(out, tuple):
                out = out[0]
        duet_close("graph_post", _ev)

        _ev_fl = duet_record("final_logits")
        logits = self.model.compute_logits(out, last_only)
        duet_close("final_logits", _ev_fl)
        # pad 행 절단 — 소비자는 [n_rows, V]만 본다
        if logits is not None and not last_only and logits.shape[0] == r_b:
            logits = logits[:n_rows]
        if logits is not None and not last_only \
                and logits.shape[0] != n_rows:
            raise RuntimeError(
                f"tree verify row invariant: logits rows="
                f"{logits.shape[0]} != n_rows={n_rows} "
                f"(valid={valid} r_b={r_b} nv_b={nv_b} "
                f"cg={_cg is not None} in_rows={input_ids.shape[0]})")
        return logits


    # should add spec_k that just loops this k times
    def run(
        self,
        seqs: list[Sequence],
        is_prefill: bool,
        last_only: bool = True,
        draft_return_logits: bool = False,
        hidden_states: torch.Tensor | None = None,
        step_lookahead: int | None = None,
        tree_meta: list | None = None,
    ) -> list[int] | tuple[list[int], torch.Tensor]:
        # v1 hybrid: step_lookahead must be the same on every TP rank for the
        # CG bucket dispatch to stay in sync (otherwise rank 0 picks
        # verify_short while rank 1 picks verify_long → NCCL collective
        # mismatch → deadlock). Goes through call() / write_shm so all ranks
        # see it.
        if step_lookahead is not None:
            self._duet_step_lookahead = int(step_lookahead)
        # T3.4-b4: 트리 verify 메타 (tree_ints 리스트) — SHM으로 전 rank
        # 동일 수신. None이면 리셋 (체인 step이 트리 분기를 타지 않도록
        # 매 호출 무조건 대입).
        self._duet_tree_meta = tree_meta
        _pt = os.environ.get("SSD_PROFILE_TARGET", "0") == "1" and not is_prefill and not last_only
        if _pt:
            torch.cuda.synchronize()
            _r0 = time.perf_counter()

        if is_prefill:
            input_ids, positions = self.prepare_prefill(seqs)
        else:
            input_ids, positions = self.prepare_decode(seqs, verify=not last_only)
        temperatures = self.prepare_sample(seqs) if self.rank == 0 else None

        if _pt:
            torch.cuda.synchronize()
            _r1 = time.perf_counter()

        # Handle EAGLE returning (logits, conditioning_vector for next iter)
        conditioning = None
        if self.config.use_eagle:
            logits, conditioning = self.run_model(
                input_ids, positions, is_prefill, last_only, hidden_states=hidden_states)
        else:
            logits = self.run_model(input_ids, positions, is_prefill, last_only, hidden_states=hidden_states)

        if _pt:
            torch.cuda.synchronize()
            _r2 = time.perf_counter()
            print(f"[PROFILE target_run] prepare_decode={(_r1-_r0)*1000:.2f}ms run_model={(_r2-_r1)*1000:.2f}ms eagle={self.config.use_eagle} n_ids={input_ids.shape[0]}", flush=True)

        if last_only:
            token_ids = self.sampler(logits, temperatures).tolist() if self.rank == 0 else None
            reset_context()
            if conditioning is not None:
                return token_ids, conditioning
            return (token_ids, logits) if draft_return_logits else token_ids
        else:
            reset_context()
            if conditioning is not None:
                return logits, conditioning
            return logits
    
