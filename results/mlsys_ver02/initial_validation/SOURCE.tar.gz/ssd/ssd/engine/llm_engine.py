import os
import ssd.paths  # noqa: F401 — sets TORCH_CUDA_ARCH_LIST before flashinfer import

from ssd.config import Config
from ssd.sampling_params import SamplingParams
from ssd.utils.misc import validate_speculative_vocab
from ssd.engine.sequence import Sequence
from ssd.engine.scheduler import Scheduler
from ssd.engine.model_runner import ModelRunner
from ssd.engine.draft_runner import DraftRunner
from ssd.engine.speculator_async import SpeculatorAsync
from ssd.engine.speculator_sync import SpeculatorSync
from ssd.engine.step import InferenceStep, AutoRegressiveStep, SpecDecodeStep
from ssd.engine.verifier import Verifier

import atexit
import threading
from dataclasses import fields
from time import perf_counter
from tqdm.auto import tqdm
from transformers import AutoTokenizer
import torch.multiprocessing as mp



METRICS = {
    "cache_hits": [],
    "phase1_hits": [],   # DUET-only: fraction of B with phase 1 (draft-sourced) cache hit
    "phase2_hits": [],   # DUET-only: fraction of B with phase 2 (proxy-sourced) cache hit
    "accepted_suffix_lens_with_recovery": [],
    "accepted_suffix_lens_on_hit": [],  # Only for cache hits in async mode
    "accepted_suffix_lens_on_miss": [],  # Only for cache misses in async mode
    "accepted_lens_phase1_hit": [],  # accepted speculative tokens, excludes recovery token
    "accepted_lens_phase2_hit": [],  # accepted speculative tokens, excludes recovery token
    # Optional analysis payload consumed by run_duet --emit-phase-trace.
    # One compact record per verified sequence/step.  Keeping the event order
    # lets offline analysis map each source decision to the realized output
    # prefix without adding file I/O to the engine hot path.
    "phase_events": [],
    "decode_steps": [],
    "prefill_total_time": 0,
    "decode_total_time": 0,
    "prefill_total_tokens": 0,
    "decode_total_tokens": 0,
    "target_step_times": [],
    "target_verify_times": [],
}


class LLMEngine:

    def __init__(self, model, **kwargs):
        config_fields = {field.name for field in fields(Config)}
        config_kwargs = {k: v for k, v in kwargs.items() if k in config_fields}
        config = Config(model, **config_kwargs)
        self.config = config
        if config.speculate and not config.draft_async:
            from ssd.layers.layernorm import prepare_norms_for_colocation
            prepare_norms_for_colocation()
        Sequence.block_size = config.kvcache_block_size 

        assert config.kvcache_block_size >= (
            2 * config.speculate_k + 2), "ERROR: support for block size < 2*k+2 is not implemented"
        assert config.num_gpus > 1 or not config.draft_async, "ERROR: draft_async requires at least 2 gpus"
            
        self.tokenizer = AutoTokenizer.from_pretrained(config.model, use_fast=True)
        # EAGLE uses the target's token IDs by construction and may not ship
        # a separate tokenizer. Independent draft models must prove the map.
        if config.speculate and not config.use_eagle:
            validate_speculative_vocab(
                self.tokenizer,
                AutoTokenizer.from_pretrained(config.draft, use_fast=True),
                config.hf_config.vocab_size, config.draft_hf_config.vocab_size)
        os.environ.setdefault("SSD_SHM_NAME", f"ssd_{os.getpid()}")

        self.ps = []
        self.events = []
        self._exiting = False

        ctx = mp.get_context("spawn")
        self.num_tp_gpus = config.num_gpus if not self.config.draft_async else config.num_gpus - 1

        from ssd.engine.helpers.batch_tree_common import enabled as batch_tree_enabled
        if batch_tree_enabled(config):
            from ssd.engine.helpers.batch_tree_forward import proxy_stream_enabled
            replica_source = 'default' if 'SSD_DUET_EXIT_REPLICA' not in os.environ else 'env'
            stream_source = 'auto' if 'SSD_BATCH_TREE_PROXY_STREAM' not in os.environ else 'env'
            print(f'[duet-tree-runtime] batch={config.max_num_seqs} target_tp={self.num_tp_gpus} '
                  f'exit_replica={int(config.duet_exit_replica)} source={replica_source} '
                  f'proxy_stream={int(proxy_stream_enabled(config, self.num_tp_gpus))} '
                  f'stream_source={stream_source}', flush=True)

        if config.speculate and config.draft_async:
            self.draft_ps = None

        for i in range(1, self.num_tp_gpus):
            if self.config.verbose:
                print(f'creating ModelRunner process {i}', flush=True)
            event = ctx.Event()
            # can't pass kwargs through ctx.Process args
            process = ctx.Process(target=ModelRunner, args=(
                config, i, event, False, self.num_tp_gpus))
            process.start()
            self.ps.append(process)
            self.events.append(event)

        if self.config.verbose:
            print(
                f'config.speculate = {config.speculate} and config.draft_async = {config.draft_async} about to create draft runner', flush=True)

        if config.speculate and config.draft_async:
            init_q = ctx.Queue()
            draft_rank = config.num_gpus - 1
            self.draft_ps = ctx.Process(
                target=DraftRunner, args=(config, draft_rank, init_q))
            self.draft_ps.start()
            self._draft_watch_stop = threading.Event()
            self._draft_watch_thread = threading.Thread(
                target=self._watch_draft_process,
                name="ssd-draft-watchdog", daemon=True)
            self._draft_watch_thread.start()
            print(
                f'Draft runner created on rank {draft_rank} (async)!', flush=True)

        # modelRunner(0) will wait on all 5 processes, so other 4 need to have launched by now
        self.model_runner = ModelRunner(
            config, 0, self.events, is_draft=False, num_tp_gpus=self.num_tp_gpus)

        # do this after so we can launch model runner above so that the q is actually populated
        if config.speculate and config.draft_async:
            try:
                num_blocks = init_q.get(timeout=180)  # seconds
            except Exception as e:
                raise RuntimeError(
                    "ERROR: Timed out waiting for draft kv cache size") from e

            try:
                draft_ready = init_q.get(timeout=300)
            except Exception as e:
                raise RuntimeError(
                    "ERROR: Timed out waiting for draft CUDA graph warmup") from e
            if not (isinstance(draft_ready, tuple)
                    and len(draft_ready) == 2
                    and draft_ready[0] == "draft_ready"):
                raise RuntimeError(
                    f"ERROR: Invalid draft readiness message: {draft_ready!r}")

            init_q.close()
            self.draft_cfg = DraftRunner.create_draft_config(config)
            self.draft_cfg.num_kvcache_blocks = num_blocks  # set for block manager to knwo

            self.prev_allocated_blocks = None
            self.prev_blocks_per_fork = None

        if config.speculate and not config.draft_async:
            # keep it colocated on rank 0, process/dist agnostic in this case
            self.draft_runner = DraftRunner(config)
            self.draft_cfg = self.draft_runner.draft_cfg
            print(f'Draft runner created on rank 0 (no async)', flush=True)

        if self.model_runner.batched_tree_enabled:
            from ssd.engine.helpers.batch_tree_warmup import prewarm_target
            prewarm_target(self.model_runner)

        config.eos = self.tokenizer.eos_token_id
        self.scheduler = Scheduler(config, draft_cfg=self.draft_cfg if config.speculate else None)
        assert config.max_model_len == self.scheduler.max_model_len

        print(f"[LLMEngine] finished llm_engine init", flush=True)

        atexit.register(lambda: self.exit(hard=True))

    def _watch_draft_process(self):
        """Fail the whole engine when the standalone draft worker dies.

        Rank 0 can be blocked inside NCCL when the draft process hits a CUDA
        assert.  Waiting for normal exception propagation therefore leaves
        the target workers spinning indefinitely.  A parent-side process
        watcher does not depend on CUDA/NCCL progress and can tear the run
        down promptly, matching the fail-fast worker supervision used by
        high-throughput serving runtimes.
        """
        stop = self._draft_watch_stop
        while not stop.wait(0.5):
            proc = getattr(self, "draft_ps", None)
            if proc is None or proc.is_alive():
                continue
            if getattr(self, "_exiting", False):
                return
            code = proc.exitcode
            print(
                f"[LLMEngine] FATAL: draft runner exited unexpectedly "
                f"(exitcode={code}); terminating target workers",
                flush=True)
            workers = list(getattr(self, "ps", ()))
            for worker in workers:
                try:
                    if worker.is_alive():
                        worker.terminate()
                except Exception:
                    pass
            for worker in workers:
                try:
                    worker.join(timeout=1)
                    if worker.is_alive():
                        worker.kill()
                except Exception:
                    pass
            os._exit(code if isinstance(code, int) and code > 0 else 1)

    def exit(self, hard: bool = True):
        print(f"[LLMEngine] Exiting (hard={hard})", flush=True)
        if getattr(self, "_exiting", False):
            return
        self._exiting = True
        watch_stop = getattr(self, "_draft_watch_stop", None)
        if watch_stop is not None:
            watch_stop.set()
        try:
            from ssd.engine.helpers.cudagraph_helpers import duet_dump
            duet_dump("target_rank0")
        except Exception:
            pass
        # 0) Batch 3a (docs/duet/08 §3.3): drain outstanding proxy isend Work
        # handles BEFORE tearing down the process group. An isend interacting
        # with a closed PG can hang or segfault. Guard against absent verifier
        # (non-spec runs).
        try:
            _verifier = getattr(self, "verifier", None)
            if _verifier is not None and hasattr(_verifier, "drain_proxy_send_ring"):
                _verifier.drain_proxy_send_ring()
        except Exception as e:
            print(f"[llm_engine] proxy_send_ring drain warning: {e}", flush=True)

        # 1) If async, tell draft to quit before tearing down anything
        try:
            if self.config.speculate and self.config.draft_async:
                # Use local method (no SHM) to send cmd=2
                self.model_runner.send_draft_exit_signal()
        except Exception:
            pass
        # 2) Tell all target ranks (including rank 0 self) to exit (non-blocking cleanup, no os._exit inside)
        try:
            self.model_runner.call("exit",
                                   True if not self.config.draft_async else True)
        except Exception:
            pass
        # 3) Wait briefly for TP workers; terminate if still around
        try:
            if self.model_runner.world_size > 1:
                for p in self.ps:
                    p.join(timeout=3)
                    if p.is_alive():
                        p.terminate()
                        p.join(timeout=2)
        except Exception:
            pass
        # 4) Draft process: profile dumps can be large, so profiling runs get a
        # longer graceful-exit window without adding another runtime env knob.
        _draft_join_timeout = 30 if os.environ.get("SSD_PROFILE_DUET", "0") == "1" else 3
        try:
            if self.config.speculate and self.config.draft_async and self.draft_ps is not None:
                self.draft_ps.join(timeout=_draft_join_timeout)
                if self.draft_ps.is_alive():
                    self.draft_ps.terminate()
                    self.draft_ps.join(timeout=2)
        except Exception:
            pass
        # Multiprocessing owns its own semaphores; preserve other engines.
        # 6) Force-exit current process if requested
        if hard:
            os._exit(0)

    def add_request(self, prompt: str | list[int], sampling_params: SamplingParams):
        if self.config.stochastic_only and (sampling_params.temperature <= 0
                or (sampling_params.draft_temperature is not None and sampling_params.draft_temperature <= 0)):
            raise ValueError("stochastic_only requires positive target and draft temperatures")
        if self.config.greedy_only and (sampling_params.temperature != 0
                or sampling_params.draft_temperature not in (None, 0)):
            raise ValueError("greedy_only requires target and draft temperature zero")
        # The legacy top-M wire omits the full vocabulary partition at other
        # temperatures. Reject unsupported requests before launching workers.
        if (getattr(self.config, "duet_enabled", False) and
                (self.config.duet_proxy_on_draft or self.config.duet_exit_topm_gather) and
                (sampling_params.temperature not in (0.0, 1.0) or
                 sampling_params.draft_temperature not in (None, 0.0, 1.0))):
            raise ValueError("Legacy raw/top-M proxy requires T1 ranking; use the default full-vocabulary proxy for actual temperatures")
        if isinstance(prompt, str):
            prompt = self.tokenizer.encode(prompt)
        seq = Sequence(prompt, sampling_params)
        self.scheduler.add(seq)


    def step(self, step: InferenceStep):
        t = perf_counter()
        event_start = len(METRICS["phase_events"])
        seqs, is_prefill = self.scheduler.schedule()
        if is_prefill is None:
            # Scheduler-side context termination: the completed prefix is
            # returned without launching a model kernel beyond the native
            # context window.
            ttl_tokens = 0
        else:
            ttl_tokens = step.prefill(seqs) if is_prefill else step.decode(seqs)

        time_taken = perf_counter() - t

        if is_prefill is None:
            pass
        elif is_prefill:
            METRICS["prefill_total_time"] += time_taken
            METRICS["prefill_total_tokens"] += ttl_tokens
        else:
            METRICS["decode_total_time"] += time_taken
            METRICS["decode_total_tokens"] += ttl_tokens
            events = METRICS["phase_events"][event_start:]
            METRICS["decode_steps"].append(dict(
                seconds=time_taken, emitted_tokens=ttl_tokens, batch_size=len(seqs),
                event_start=event_start, event_end=len(METRICS["phase_events"]),
                output_cap_reached=any(s.num_completion_tokens >= s.max_new_tokens for s in seqs),
                clipped=any(e.get("clipped", False) for e in events)))

        outputs = [(seq.seq_id, seq.completion_token_ids)
                   for seq in seqs if seq.is_finished]

        return outputs

    def is_finished(self):
        return self.scheduler.is_finished()

    def log_metrics(self):
        from ssd.utils.performance import performance_summary
        selected = performance_summary(METRICS, self.config.max_num_seqs)
        prefill_time = float(METRICS["prefill_total_time"])
        decode_time = float(METRICS["decode_total_time"])
        avg_prefill_throughput = (
            METRICS["prefill_total_tokens"] / prefill_time
            if prefill_time > 0.0 else 0.0)
        avg_decode_throughput = (
            METRICS["decode_total_tokens"] / decode_time
            if decode_time > 0.0 else 0.0)
        print(
            f"Final Prefill Throughput: {avg_prefill_throughput:.2f}tok/s", flush=True)
        print(
            f"Final Decode Throughput: {selected['tps'] or 0.0:.2f}tok/s", flush=True)
        print(f"[metrics] Performance population: { {k:v for k,v in selected.items() if k != 'included_step_indices'} }", flush=True)
        print(f"[raw metrics] All decode throughput: {avg_decode_throughput:.2f}tok/s", flush=True)
        print(
            f"[metrics] Prefill tokens/time: {METRICS['prefill_total_tokens']} / "
            f"{METRICS['prefill_total_time']:.6f}s", flush=True)
        print(
            f"[metrics] Decode tokens/time: {METRICS['decode_total_tokens']} / "
            f"{METRICS['decode_total_time']:.6f}s", flush=True)

        if self.config.speculate:
            ttl_accepted_with_recovery = sum(METRICS['accepted_suffix_lens_with_recovery'])
            ttl_num_spec_steps = len(METRICS['accepted_suffix_lens_with_recovery'])
            # A native-context request can finish in the scheduler before its
            # first decode launch.  That is a valid context-limit result, not
            # an engine failure.  Keep the standard throughput lines above
            # machine-readable and avoid dividing every speculative metric by
            # an empty step list.
            if ttl_num_spec_steps == 0:
                print(
                    "[metrics] Speculative decode: N/A (no decode steps)",
                    flush=True)
                return
            avg_tokens_per_step = ttl_accepted_with_recovery / ttl_num_spec_steps
            selected_al = f"{selected['al']:.2f}" if selected['al'] is not None else "N/A"
            print(f"[metrics] Avg Tokens per step (incl recovery): {selected_al}", flush=True)
            print(f"[raw metrics] All-event accepted length: {avg_tokens_per_step:.2f}", flush=True)

            total_accepted = ttl_accepted_with_recovery - ttl_num_spec_steps
            # Split-only K1/K2 mode: effective spec depth is K_max = max(K1, K2),
            # not K_long = K1+K2. Use K_max so accept fraction is comparable to
            # baseline async-SSD k=K_max.
            import os as _os_metric
            _split_k1k2 = (
                _os_metric.environ.get("SSD_FORCE_SPLIT_K1K2", "0") == "1"
                and self.config.duet_phase1_k is not None
            )
            if _split_k1k2:
                _accept_denom = max(self.config.duet_phase1_k, self.config.duet_phase2_k)
            else:
                _accept_denom = self.config.speculate_k
            avg_acceptance_rate = (total_accepted / ttl_num_spec_steps) / _accept_denom
            print(
                f"[metrics] Avg Fraction of Speculated Tokens Accepted: {avg_acceptance_rate:.2f} "
                f"(denom={_accept_denom})", flush=True)
            print(
                f"[metrics] Avg target time per full step (ms): {sum(METRICS['target_step_times']) * 1000 / len(METRICS['target_step_times']):.2f}", flush=True)
            if METRICS['target_verify_times']:
                print(
                    f"[metrics] Avg target verify time (ms): {sum(METRICS['target_verify_times']) * 1000 / len(METRICS['target_verify_times']):.2f}", flush=True)
            if self.config.draft_async:
                selected_hit = f"{selected['cache_hit']:.2f}" if selected['cache_hit'] is not None else "N/A"
                print(f"[metrics] Avg Cache Hits: {selected_hit}", flush=True)
                print(f"[raw metrics] All-event cache hit: {sum(METRICS['cache_hits']) / len(METRICS['cache_hits']):.2f}", flush=True)
                # DUET-only: phase 1 (draft-sourced) vs phase 2 (proxy-sourced) hit split.
                # Non-DUET paths leave these zero.
                if self.config.duet_enabled and METRICS['phase1_hits']:
                    p1 = sum(METRICS['phase1_hits']) / len(METRICS['phase1_hits'])
                    p2 = sum(METRICS['phase2_hits']) / len(METRICS['phase2_hits'])
                    print(f"[metrics] Avg Phase 1 (draft) Hit Rate: {p1:.3f}", flush=True)
                    print(f"[metrics] Avg Phase 2 (proxy) Hit Rate: {p2:.3f}", flush=True)
                    if METRICS["accepted_lens_phase1_hit"]:
                        p1_len = sum(METRICS["accepted_lens_phase1_hit"]) / len(METRICS["accepted_lens_phase1_hit"])
                        p1_denom = self.config.duet_phase1_k if self.config.duet_phase1_k is not None else self.config.speculate_k
                        print(f"[metrics] Avg Phase 1 Accepted Len: {p1_len:.2f}", flush=True)
                        print(f"[metrics] Avg Phase 1 Acceptance Ratio: {p1_len / p1_denom:.3f}", flush=True)
                    if METRICS["accepted_lens_phase2_hit"]:
                        p2_len = sum(METRICS["accepted_lens_phase2_hit"]) / len(METRICS["accepted_lens_phase2_hit"])
                        p2_denom = self.config.duet_phase2_k if self.config.duet_phase2_k is not None else self.config.speculate_k
                        print(f"[metrics] Avg Phase 2 Accepted Len: {p2_len:.2f}", flush=True)
                        print(f"[metrics] Avg Phase 2 Acceptance Ratio: {p2_len / p2_denom:.3f}", flush=True)
                # Log separate metrics for cache hits
                if METRICS['accepted_suffix_lens_on_hit']:
                    avg_suffix_len_on_hit = sum(
                        METRICS['accepted_suffix_lens_on_hit']) / len(METRICS['accepted_suffix_lens_on_hit'])
                    print(
                        f"[metrics] Avg Tokens per step on Cache Hit: {avg_suffix_len_on_hit:.2f}", flush=True)
                    
                    # Calculate empirical frequencies of accepted_suffix_lens_on_hit - 1
                    adjusted_lens = [length - 1 for length in METRICS['accepted_suffix_lens_on_hit']]
                    total_count = len(adjusted_lens)
                    freq_counts = {}
                    for length in adjusted_lens:
                        freq_counts[length] = freq_counts.get(length, 0) + 1
                    
                    # Print normalized empirical probabilities for range [0, K]
                    print(f"[metrics] Empirical frequencies of accepted_suffix_lens_on_hit - 1:", flush=True)
                    for k in range(self.config.speculate_k + 1):
                        prob = freq_counts.get(k, 0) / total_count
                        print(f"  {k}: {prob:.3f}", flush=True)
                if METRICS['accepted_suffix_lens_on_miss']:
                    avg_suffix_len_on_miss = sum(
                        METRICS['accepted_suffix_lens_on_miss']) / len(METRICS['accepted_suffix_lens_on_miss'])
                    print(
                        f"[metrics] Avg Tokens per step on Cache Miss: {avg_suffix_len_on_miss:.2f}", flush=True)
                else:
                    print(
                        f"[metrics] Avg Tokens per step on Cache Hit: N/A (no cache hits)", flush=True)

    def create_inference_step(self, config: Config) -> InferenceStep:
        if config.speculate:
            if config.draft_async:
                speculator = SpeculatorAsync(
                    lookahead=config.speculate_k,
                    device=config.device,
                    async_fan_out=config.async_fan_out,
                    max_blocks=config.max_blocks,
                    vocab_size=config.draft_hf_config.vocab_size,
                    draft_dtype=config.draft_hf_config.torch_dtype,
                    kvcache_block_size=config.kvcache_block_size,
                    max_model_len=config.max_model_len,
                    async_pg=self.model_runner.async_pg,
                    draft_runner_rank=self.num_tp_gpus,
                    tokenizer=self.tokenizer,
                    verbose=config.verbose,
                    config=config,
                )
            else:
                speculator = SpeculatorSync(
                    lookahead=config.speculate_k,
                    device=config.device,
                    draft_model_runner=self.draft_runner,
                )

            verifier = Verifier(
                lookahead=config.speculate_k,
                device=config.device,
                target_model_runner=self.model_runner,
                sampler_x=config.sampler_x,
                async_fan_out=config.async_fan_out,
                jit_speculate=config.jit_speculate,
                tokenizer=self.tokenizer,
                metrics=METRICS,
            )
            # Batch 3a: keep verifier on engine so exit() can drain the proxy
            # send ring before joining the draft process (docs/duet/08 §3.3).
            self.verifier = verifier
            return SpecDecodeStep(
                scheduler=self.scheduler,
                speculator=speculator,
                verifier=verifier,
                eagle=config.use_eagle,
                tokenizer=self.tokenizer,
                async_spec=config.draft_async,
            )
        else:
            return AutoRegressiveStep(
                scheduler=self.scheduler,
                model_runner=self.model_runner,
                tokenizer=self.tokenizer,
            )

    def generate(
        self,
        prompts: list[str] | list[list[int]],
        sampling_params: SamplingParams | list[SamplingParams],
        use_tqdm: bool = True,
        stream_callback=None,
    ) -> list[str]:
        for k in METRICS:
            METRICS[k] = [] if isinstance(METRICS[k], list) else 0

        if use_tqdm:
            pbar = tqdm(total=len(prompts),
                        desc="Generating", dynamic_ncols=True)
        if not isinstance(sampling_params, list):
            sampling_params = [sampling_params] * len(prompts)
        for prompt, sp in zip(prompts, sampling_params):
            self.add_request(prompt, sp)

        outputs = {}
        inference_step = self.create_inference_step(self.config)
        i = 0
        max_steps = self.config.max_steps if self.config.max_steps is not None else float('inf')
        _stream_lens = {}
        while not self.is_finished() and i < max_steps:
            if self.config.verbose:
                print(f"[generate] step {i+1}" +
                    f" of {max_steps}" if max_steps != float('inf') else "",
                    flush=True,
                )
            i += 1
            t = perf_counter()
            output = self.step(inference_step)
            time_taken = perf_counter() - t
            METRICS["target_step_times"].append(time_taken)

            if stream_callback:
                for seq in self.scheduler.running:
                    cur = seq.num_completion_tokens
                    prev = _stream_lens.get(seq.seq_id, 0)
                    if cur > prev:
                        stream_callback(seq.seq_id, seq.completion_token_ids[prev:cur])
                        _stream_lens[seq.seq_id] = cur

            for seq_id, token_ids in output:
                if stream_callback:
                    prev = _stream_lens.get(seq_id, 0)
                    if len(token_ids) > prev:
                        stream_callback(seq_id, token_ids[prev:])
                outputs[seq_id] = token_ids
                if use_tqdm:
                    pbar.update(1)
        outputs = [outputs[seq_id] for seq_id in sorted(outputs)]
        outputs = [{"text": self.tokenizer.decode(
            token_ids), "token_ids": token_ids} for token_ids in outputs]
        if use_tqdm:
            pbar.close()

        from ssd.utils.performance import performance_summary
        METRICS["performance"] = performance_summary(METRICS, self.config.max_num_seqs)
        if not stream_callback:
            self.log_metrics()

        return outputs, METRICS
