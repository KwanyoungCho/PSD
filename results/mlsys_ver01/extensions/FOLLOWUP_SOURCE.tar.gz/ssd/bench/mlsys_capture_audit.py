"""Record CPU intervals of rare graph construction, without CUDA profiling.

No GPU events, synchronization or extra random draws are introduced. Existing
capture labels are enabled by SSD_PROFILE_DUET_DETAIL=1. Per-step timestamps
in the review harness let the parent correlate draft-process captures too.
"""
import json
import os
from pathlib import Path
import sys
import time


def install():
    folder=os.getenv('DUET_REVIEW_CAPTURE_AUDIT')
    if not folder:return
    from ssd.engine.helpers import cudagraph_helpers as h
    if h.PROFILE_DUET:raise ValueError('Capture audit requires normal CUDA profiling OFF')
    old_record,old_close=h.duet_record,h.duet_close
    path=Path(folder);path.mkdir(parents=True,exist_ok=True)
    def record(label,parent=None):
        if 'capture' in label:
            return {'capture_audit':True,'label':label,'start_ns':time.monotonic_ns(),'pid':os.getpid()}
        return old_record(label,parent)
    def close(label,handle):
        if isinstance(handle,dict) and handle.get('capture_audit'):
            row=dict(handle,end_ns=time.monotonic_ns())
            with (path/f'capture_{os.getpid()}.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            return
        return old_close(label,handle)
    # Some helper modules were loaded by package import before this hook.
    for name,module in list(sys.modules.items()):
        if name.startswith('ssd.') and module is not None:
            if vars(module).get('duet_record') is old_record:setattr(module,'duet_record',record)
            if vars(module).get('duet_close') is old_close:setattr(module,'duet_close',close)
    h.duet_record,h.duet_close=record,close
