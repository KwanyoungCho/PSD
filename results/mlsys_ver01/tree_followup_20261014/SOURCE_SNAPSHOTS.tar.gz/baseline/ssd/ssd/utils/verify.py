import torch
from ssd.utils.async_helpers.async_spec_helpers import apply_sampler_x_rescaling
from ssd.config import Config

def _materialize_verified(speculations, counts, recovery):
    rows = torch.cat((counts[:, None], recovery[:, None], speculations), dim=1).tolist()
    return [r[2:3 + r[0]] for r in rows], [r[1] for r in rows]


def verify(
    logits_p: torch.Tensor,
    logits_q: torch.Tensor,
    speculations: torch.Tensor,
    temperatures_target,
    temperatures_draft,
    cache_hits: torch.Tensor | None = None,
    sampler_x: float | None = None,
    async_fan_out: int | None = None,
    jit_speculate: bool = False,
    valid_k: torch.Tensor | None = None,
    all_stochastic: bool = False,
    all_greedy: bool = False,
) -> tuple[list[list[int]], list[int]]:
    """
    Speculative‐decoding verification:
     - For temp==0: pure argmax‐compare (greedy).
     - For temp>0: softmax + p/q‐ratio acceptance + (re)sampling.
     - IMPORTANT: Only apply ratio acceptance on rows where the draft proposal truly
       came from q (cache hit in async mode). On cache misses, fall back to greedy
       acceptance and sample recovery directly from p.
     - valid_k (M1, docs/duet/13 §1): optional [B] int64 per-seq real suffix
       width. Rows shorter than K are padded to the batch's vk_max; the clamp
       accept_until = min(accept_until, valid_k) guarantees padded positions
       can never be accepted. None (default) keeps every other caller unchanged.
    """

    if all_greedy:
        preds = logits_p.argmax(dim=-1)
        matches = speculations[:, 1:] == preds[:, :-1]
        k = speculations.shape[1] - 1
        counts = torch.where((~matches).any(1), (~matches).int().argmax(1), k)
        if valid_k is not None:
            counts = torch.minimum(counts, valid_k)
        rows = torch.arange(logits_p.shape[0], device=logits_p.device)
        return _materialize_verified(speculations, counts, preds[rows, counts])

    if all_stochastic and jit_speculate:
        from ssd.utils.verify_fast import verify_stochastic
        return verify_stochastic(logits_p, logits_q, speculations,
            temperatures_target, temperatures_draft, valid_k,
            sampler_x, async_fan_out)

    device = logits_p.device
    B, Kp1, V = logits_p.shape
    K = Kp1 - 1

    # 1) Greedy argmax paths (for all, we precompute preds_p)
    # ------------------------------------------------------
    # draft_tokens[b,j] = speculations[b, j+1] = x_{j+1}
    draft_tokens = speculations[:, 1:]                   # [B, K]
    # preds_p[b,i] = argmax on logits_p[b,i] => p_{i+1} argmax
    preds_p = logits_p.argmax(dim=-1)                    # [B, K+1]

    # Compare x_j against preds_p[:, j] for j=0..K-1
    matches = draft_tokens == preds_p[:, :-1]            # [B, K]
    any_mismatch = (~matches).any(dim=1)                 # [B]
    first_mismatch = (~matches).int().argmax(dim=1)      # [B]
    # accept up to K if no mismatch, else up to first_mismatch
    accept_greedy = torch.where(
        any_mismatch,
        first_mismatch,
        torch.full_like(first_mismatch, K)
    )                                                    # [B]
    # 2) Ratio‐based acceptance (only needed if any temp>0)
    # ------------------------------------------------------
    temps_t = temperatures_target
    temps_q = temperatures_draft

    # Rows eligible for ratio-acceptance must both need ratio (any temp>0)
    # AND be cache hits (i.e., tokens were actually sampled from q).
    base_ratio_rows = ((temps_t > 0) | (temps_q > 0))
    
    if jit_speculate:
        ratio_rows = base_ratio_rows
    else:
        ratio_rows = base_ratio_rows & (cache_hits.to(torch.bool) if cache_hits is not None else torch.zeros_like(base_ratio_rows, dtype=torch.bool))

    do_any_ratio = ratio_rows.any().item()

    # We need probs_p for recovery sampling whenever any temps_t>0 exists,
    # regardless of whether we end up doing ratio on any row.
    need_p_probs = (temps_t > 0).any().item() or do_any_ratio

    # Prepare probability tensors as needed
    B, Kp1, V = logits_p.shape
    K = Kp1 - 1

    probs_p = None
    if need_p_probs:
        probs_p = torch.zeros(B, Kp1, V, device=device, dtype=torch.float32)
        nz_p = (temps_t > 0)
        if nz_p.any():
            t = temps_t[nz_p].unsqueeze(1).unsqueeze(2).clamp(min=1e-8)
            probs_p[nz_p] = torch.softmax((logits_p[nz_p] / t).to(torch.float32), dim=-1)
        z_p = (~nz_p)
        if z_p.any():
            argmax_p = logits_p[z_p].argmax(dim=-1)  # [Bz, K+1]
            one_hot_p = torch.zeros_like(logits_p[z_p], dtype=torch.float32)
            one_hot_p.scatter_(2, argmax_p.unsqueeze(-1), 1.0)
            probs_p[z_p] = one_hot_p

    # Ratio acceptance path (only for ratio_rows)
    if do_any_ratio:
        probs_q = torch.zeros(B, K, V, device=device, dtype=torch.float32)
        nz_q = (temps_q > 0)
        if nz_q.any():
            tq = temps_q[nz_q].unsqueeze(1).unsqueeze(2).clamp(min=1e-8)
            probs_q[nz_q] = torch.softmax((logits_q[nz_q] / tq).to(torch.float32), dim=-1)
        z_q = (~nz_q)
        if z_q.any():
            argmax_q = logits_q[z_q].argmax(dim=-1)  # [Bz, K]
            one_hot_q = torch.zeros_like(logits_q[z_q], dtype=torch.float32)
            one_hot_q.scatter_(2, argmax_q.unsqueeze(-1), 1.0)
            probs_q[z_q] = one_hot_q

        # Apply sampler_x rescaling to draft distribution if provided
        if sampler_x is not None:
            assert async_fan_out is not None, "async_fan_out must be provided if sampler_x is provided"
            probs_q = apply_sampler_x_rescaling(probs_q, sampler_x, async_fan_out)

        # gather p_i(x_i) and q_i(x_i) for i=1..K on rows doing ratio
        p_all = probs_p[:, :K, :] if probs_p is not None else torch.zeros(B, K, V, device=device, dtype=torch.float32)
        q_all = probs_q
        gather_idx = draft_tokens.unsqueeze(2)  # [B, K, 1]
        p_vals = p_all.gather(2, gather_idx).squeeze(2)  # [B, K]
        q_vals = q_all.gather(2, gather_idx).squeeze(2)  # [B, K]

        accept_probs = (p_vals / (q_vals + 1e-10)).clamp(max=1.0)  # [B, K]
        rand = torch.rand_like(accept_probs)
        accepts = rand <= accept_probs  # [B, K]

        rej_any = (~accepts).any(dim=1)  # [B]
        first_rej = (~accepts).int().argmax(dim=1)  # [B]
        accept_ratio = torch.where(
            rej_any,
            first_rej,
            torch.full_like(first_rej, K)
        )  # [B]

        # Only use ratio accept on ratio_rows; others fall back to greedy
        accept_until = torch.where(ratio_rows, accept_ratio, accept_greedy)
    else:
        # No rows use ratio; all fall back to greedy accept counts
        accept_until = accept_greedy

    # M1 (docs/duet/13 §1): per-seq acceptance clamp. At B>1 short seqs are
    # padded to the batch's vk_max = K; positions beyond a seq's real valid_k
    # must never be accepted.
    if valid_k is not None:
        accept_until = torch.minimum(accept_until, valid_k)

    # 3) Construct the recovery distribution and sample
    # For rows with temps_t>0:
    #  - If ratio_rows: use adjusted max(0, p - q) when accept<K, else p
    #  - Else (misses): sample directly from p
    # For rows with temps_t==0: use greedy
    batch_idx = torch.arange(B, device=device)
    # Recover at the real accepted prefix, after excluding padded proposal
    # positions. This also covers greedy rows in the generic/mixed path.
    rec_greedy = preds_p[batch_idx, accept_until]
    if probs_p is None:
        # No temperatures require sampling; keep greedy
        rec_ratio = rec_greedy
    else:
        p_fallback = probs_p[batch_idx, accept_until]  # [B, V]
        p_sum = p_fallback.sum(dim=1, keepdim=True)
        fallbackDist = p_fallback / p_sum

        if do_any_ratio:
            p_all = probs_p[:, :K, :]
            q_idx_safe = accept_until.clamp(max=K-1)
            # Build q_all for adjusted rows only; reuse previous q_all if available
            # We already have q_all if do_any_ratio=True (and it's already rescaled if sampler_x was provided)
            q_slice = q_all[batch_idx, q_idx_safe]  # [B, V]
            # M6 (docs/duet/13): the residual (p - q)+ adjustment applies only
            # when a REAL rejection happened. For a short row (valid_k < K)
            # accepted through all its real tokens, accept_until == valid_k is
            # a clamp, not a rejection — sample plain p at that position, as
            # the same event does at B=1 (where accept_until == K). Columns at
            # or past valid_k hold padded q (zero logits → uniform), so the
            # old K-only test subtracted a bogus uniform q there.
            _k_real = (torch.full_like(accept_until, K) if valid_k is None
                       else valid_k.clamp(max=K))
            mask_adjust = (temps_t > 0) & (accept_until < _k_real) & ratio_rows

            adj = (p_fallback - q_slice).clamp(min=0.0)
            sums = adj.sum(dim=1, keepdim=True)
            adj_norm = torch.where(sums > 0, adj / sums, fallbackDist)
            # For ratio_rows use adj_norm when adjust, else fallback; for non-ratio rows with temp>0 use fallback; temp==0 use greedy
            rec_ratio_adjusted = torch.multinomial(adj_norm, 1).squeeze(1)
            rec_from_p = torch.multinomial(fallbackDist, 1).squeeze(1)
            rec_ratio = torch.where(mask_adjust, rec_ratio_adjusted, rec_from_p)
        else:
            # No ratio rows; sample from p for temps_t>0, else greedy
            rec_from_p = torch.multinomial(fallbackDist, 1).squeeze(1)
            rec_ratio = rec_from_p

    # final recovery tokens
    rec_final = torch.where(temps_t > 0, rec_ratio, rec_greedy)      # [B]

    # 4) Materialize ragged accepted_suffixes
    # ---------------------------------------
    accepted_suffixes: list[list[int]] = []
    # previous recovery
    starts = speculations[:, 0].tolist()
    counts = accept_until.tolist()

    for b in range(B):
        n = counts[b]
        suffix = [starts[b]] + draft_tokens[b, :n].tolist()
        accepted_suffixes.append(suffix)

    return accepted_suffixes, rec_final.tolist()
