#!/bin/bash
set -eu
repo=/home/chokwans99/PSD-MLSys-ver0.1
raw=/data/chokwans99/duet-ps-prep-20261015
cd "$repo"
for arm in before_unprofiled after_unprofiled; do
 checkout="$repo"
 if [[ $arm == before* ]]; then checkout="$raw/baseline"; fi
 env CUDA_VISIBLE_DEVICES=4,5 PAPER_CHECKOUT="$checkout" PAPER_CPUSET=16-23,48-55 PAPER_ARM="$arm" PAPER_SEED=9101 SSD_TREE_EXEC=1 SSD_TREE_EXEC_WARMUP=all SSD_P1_TREE_EXEC_WARMUP=all SSD_ASYNC_PROXY_SEND=1 SSD_PROFILE_DUET=0 SSD_FORCE_SPLIT_K1K2=1 SSD_HF_CACHE=/tmp SSD_DATASET_DIR=/tmp MASTER_PORT=29631 /home/chokwans99/PSD/ssd/.venv/bin/python ssd/bench/mlsys_ps_preparation.py --mode tree --batch 1 --temperature 0.7 --prompts results/mlsys_ver02/equal_budget_20261014/SPEC_BENCH_FULL.json --limit 48 --output-tokens 96 --input-cap 512 --warm-prompts 4 --passes 1 --exit-layer 20 --k1 6 --k2 3 --p1-verify 12 --p1-nodes 12 --p2-verify 8 --p2-nodes 8 --output "$raw/runs/$arm/run.json" > "$raw/$arm.log" 2>&1
 echo "$arm finished"
done
